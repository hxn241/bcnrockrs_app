# 🏍️ Bot de Rutas Moteras Catalunya

Bot de Telegram para gestionar rutas moteras en grupo con sistema de valoraciones y gestión de asistentes.

## � Estructura del Proyecto

```
telegrambot_motorbike_routes/
├── bot_grupo.py           # Bot principal con funcionalidad completa
├── database.py            # Gestión de base de datos SQLite
├── config.py             # Configuración del bot
├── .env                  # Variables de entorno (TOKEN, GROUP_ID, etc.)
├── rutas_moto.db         # Base de datos con 18 rutas moteras
├── requirements.txt      # Dependencias de Python
├── iniciar_bot.sh       # Script para lanzar el bot
├── verificar_db.sh      # Script para verificar estado de la BD
└── README.md            # Este archivo
```

## � Inicio Rápido

### 1. Configurar el entorno:
```bash
# Activar entorno virtual
source /home/cristian/projects/.venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt
```

### 2. Configurar el bot:
Editar el archivo `.env` con:
```bash
TELEGRAM_TOKEN=tu_token_de_botfather
GROUP_CHAT_ID=id_del_grupo
ADMIN_USER_IDS=tu_user_id
```

### 3. Lanzar el bot:
```bash
./iniciar_bot.sh
```

## 🎮 Comandos Disponibles

### Para todos los usuarios:
- `/rutas` - Ver todas las rutas y seleccionar una para publicar
- `/rutas_del_dia` - Ver rutas publicadas hoy
- `/valorar [1-5]` - Valorar la ruta publicada
- `/ayuda` - Ver lista de comandos

### Solo para administradores:
- `/publicar [número]` - Publicar ruta específica por ID
- `/despublicar` - Quitar la ruta publicada
- `/estadisticas` - Ver estadísticas del grupo

## 🗃️ Base de Datos

El bot utiliza SQLite con 3 tablas principales:

- **rutas**: 18 rutas moteras de Catalunya
- **rutas_publicadas**: Rutas publicadas en el grupo con fecha/hora
- **asistentes**: Usuarios que confirman asistencia con valoraciones

## �️ Scripts de Utilidad

- `./iniciar_bot.sh` - Lanza el bot con verificaciones
- `./verificar_db.sh` - Muestra estadísticas de la base de datos

## � Características

- ✅ **18 rutas moteras** precargadas
- ✅ **Restricción por grupo** (solo funciona en el grupo configurado)  
- ✅ **Límite diario** (máximo 5 rutas por día)
- ✅ **Sistema de valoraciones** (1-5 estrellas)
- ✅ **Gestión de asistentes** automática
- ✅ **Comandos de administrador** protegidos
- ✅ **Puntos de encuentro** personalizables
- ✅ **Enlaces a restaurantes** opcionales

## 🔧 Desarrollo

Para añadir nuevas rutas o modificar funcionalidades, editar:
- `database.py` - Para operaciones de base de datos
- `bot_grupo.py` - Para comandos y lógica del bot
- `config.py` - Para configuración general

---

**Desarrollado para el grupo de moteros de Catalunya** 🏍️🏴󠁥󠁳󠁣󠁴󠁿
