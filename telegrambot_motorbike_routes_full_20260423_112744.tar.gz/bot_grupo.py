#!/usr/bin/env python3
"""
Bot de Telegram para gestión de rutas moteras en grupo
Versión mejorada con vista previa y edición de rutas
"""

import logging
import sqlite3
import calendar
from datetime import date, datetime, timedelta, time
from typing import Dict, List, Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode
from database import Database
from config import *

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=getattr(logging, LOG_LEVEL, logging.INFO)
)
logger = logging.getLogger(__name__)

# Constantes
MAX_RUTAS_POR_DIA = 5

class TelegramBotGrupo:
    def __init__(self):
        self.db = Database()
        
    async def _send_message_to_group(self, context: ContextTypes.DEFAULT_TYPE, text: str, **kwargs) -> any:
        """Envía un mensaje al grupo, incluyendo el thread_id si está configurado"""
        send_params = {
            'chat_id': GROUP_CHAT_ID,
            'text': text,
            **kwargs
        }
        
        # Añadir message_thread_id si está configurado
        if RUTAS_THREAD_ID:
            try:
                send_params['message_thread_id'] = int(RUTAS_THREAD_ID)
            except (ValueError, TypeError):
                print(f"Warning: RUTAS_THREAD_ID '{RUTAS_THREAD_ID}' no es un número válido")
        
        return await context.bot.send_message(**send_params)
        
    def is_group_chat(self, update: Update) -> bool:
        """Verifica si el mensaje viene del grupo configurado"""
        if not GROUP_CHAT_ID:
            return True  # Si no hay grupo configurado, funciona en cualquier chat
        
        chat_id = update.effective_chat.id
        return str(chat_id) == str(GROUP_CHAT_ID)
    
    def can_use_bot(self, update: Update, only_private: bool = False) -> bool:
        """Verifica si el usuario puede usar el bot. Si only_private=True, solo permite en privado."""
        chat_id = update.effective_chat.id
        if only_private:
            return chat_id > 0
        if GROUP_CHAT_ID and str(chat_id) == str(GROUP_CHAT_ID):
            return False
        if chat_id > 0:
            return True
        return False
    
    def is_admin(self, user_id: int) -> bool:
        """Verifica si el usuario es administrador"""
        return str(user_id) in ADMIN_USER_IDS

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando /start"""
        if not self.can_use_bot(update, only_private=True):
            await update.message.reply_text("❌ El menú y la gestión de rutas solo están disponibles en privado. Escribe al bot directamente.")
            return
            
        mensaje = """
🏍️ **¡Bienvenido al Bot de Rutas Moteras!** 🏍️

Este bot te ayuda a gestionar y participar en rutas moteras.

**🎯 Funciones principales:**
• Ver rutas disponibles
• Consultar rutas del día
• Apuntarse a rutas con botones
• Gestión automática de fechas vencidas

¡Usa los botones de abajo para empezar! 🏍️
        """
        
        await self.mostrar_menu_principal(update, context, mensaje)

    async def menu_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja los callbacks del menú principal"""
        query = update.callback_query
        await query.answer()
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ El menú solo está disponible en privado. Escribe al bot directamente.")
            return
        
        callback_data = query.data
        
        if callback_data == "menu_rutas":
            # Mostrar rutas con callback
            await self._mostrar_rutas_callback(update, context)
            
        elif callback_data == "menu_rutas_del_dia":
            # Mostrar rutas del día con callback
            await self._rutas_del_dia_callback(update, context)
            
        elif callback_data == "menu_publicadas":
            # Permitir a cualquier usuario gestionar rutas publicadas
            user_id = update.effective_user.id
            # if not self.is_admin(user_id):
            #     await query.edit_message_text("❌ Solo los administradores pueden gestionar rutas publicadas.")
            #     return
            # Mostrar rutas publicadas con callback
            await self._publicadas_callback(update, context)
            
        elif callback_data == "menu_anadir_ruta":
            # Iniciar proceso para añadir nueva ruta
            await self._iniciar_anadir_ruta_callback(update, context)
            
        elif callback_data == "menu_ayuda":
            # Mostrar ayuda con botón de volver
            mensaje = """
🆘 **AYUDA - Bot de Rutas Moteras** 🆘

**📱 COMANDOS DISPONIBLES:**
• `/rutas` - Ver todas las rutas disponibles
• `/rutas_del_dia` - Ver rutas publicadas hoy
• `/publicadas` - Gestionar rutas publicadas
• `/ayuda` o `/help` - Mostrar esta ayuda

**📊 INFORMACIÓN:**
• Máximo {MAX_RUTAS_POR_DIA} rutas por día
• Cualquier usuario puede publicar rutas
• Usa los botones para apuntarte a las rutas
• Recordatorio automático todos los días a las 9:00 AM

**🏍️ ¿Cómo usar?**
1. Usa "🏍️ Ver Rutas" para ver todas las rutas disponibles
2. Selecciona una ruta con los botones
3. Edita fecha, hora y puntos si es necesario
4. Confirma la publicación
5. Los usuarios usan los botones para apuntarse

**👥 Asistentes:**
• Haz clic en "👍 Apuntarme" para apuntarte
• Haz clic en "� Desapuntarme" para desapuntarte
• La lista se actualiza automáticamente

**🔔 Recordatorio diario:**
• Todos los días a las 9:00 AM se muestran las rutas publicadas
• Incluye resumen de asistentes y fechas

**🧹 Limpieza automática:**
• Todos los días a las 00:01 AM se eliminan rutas vencidas
• Las rutas con fecha anterior al día actual son eliminadas automáticamente
• Los asistentes de rutas vencidas también son eliminados

¡Disfruta de las rutas! 🛣️✨
            """.format(MAX_RUTAS_POR_DIA=MAX_RUTAS_POR_DIA)
            
            # Botón para volver al menú
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(mensaje, parse_mode='Markdown', reply_markup=reply_markup)

    async def volver_menu_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handler para volver al menú principal"""
        query = update.callback_query
        await query.answer()
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ El menú solo está disponible en privado. Escribe al bot directamente.")
            return
            
        await self.mostrar_menu_principal(update, context)

    async def ayuda(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando /ayuda"""
        if not self.can_use_bot(update, only_private=True):
            await update.message.reply_text("❌ La ayuda y el menú solo están disponibles en privado. Escribe al bot directamente.")
            return
            
        mensaje = """
🆘 **AYUDA - Bot de Rutas Moteras** 🆘

**📱 COMANDOS DISPONIBLES:**
• `/rutas` - Ver todas las rutas disponibles
• `/rutas_del_dia` - Ver rutas publicadas hoy
• `/publicadas` - Gestionar rutas publicadas
• `/ayuda` o `/help` - Mostrar esta ayuda

**📊 INFORMACIÓN:**
• Máximo {MAX_RUTAS_POR_DIA} rutas por día
• Cualquier usuario puede publicar rutas
• Usa los botones para apuntarte a las rutas
• Recordatorio automático todos los días a las 9:00 AM

**🏍️ ¿Cómo usar?**
1. Usa `/menu` o "🏍️ Ver Rutas" para ver todas las rutas disponibles
2. Selecciona una ruta con los botones
3. Edita fecha, hora y puntos si es necesario
4. Confirma la publicación
5. Los usuarios usan los botones para apuntarse

**👥 Asistentes:**
• Haz clic en "👍 Apuntarme" para apuntarte
• Haz clic en "� Desapuntarme" para desapuntarte
• La lista se actualiza automáticamente

**🔔 Recordatorio diario:**
• Todos los días a las 9:00 AM se muestran las rutas publicadas
• Incluye resumen de asistentes y fechas

**🧹 Limpieza automática:**
• Todos los días a las 00:01 AM se eliminan rutas vencidas
• Las rutas con fecha anterior al día actual son eliminadas automáticamente
• Los asistentes de rutas vencidas también son eliminados

¡Disfruta de las rutas! 🛣️✨
        """.format(MAX_RUTAS_POR_DIA=MAX_RUTAS_POR_DIA)
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

    async def mostrar_mi_id(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando temporal para mostrar el ID del usuario"""
        user_id = update.effective_user.id
        username = update.effective_user.username or "Sin username"
        first_name = update.effective_user.first_name or "Sin nombre"
        
        # Escapar caracteres especiales para HTML
        username_safe = username.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        first_name_safe = first_name.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        
        mensaje = f"""🆔 <b>Tu información de usuario:</b>

• <b>ID:</b> <code>{user_id}</code>
• <b>Username:</b> {username_safe}
• <b>Nombre:</b> {first_name_safe}

<b>🔧 Para agregar como administrador:</b>
Copia este ID y agrégalo al archivo config.py en ADMIN_USER_IDS"""
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML)

    async def mostrar_info_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando temporal para mostrar información del chat actual"""
        chat_id = update.effective_chat.id
        chat_title = update.effective_chat.title or "Chat privado"
        chat_type = update.effective_chat.type
        user_id = update.effective_user.id
        username = update.effective_user.username or "Sin username"
        first_name = update.effective_user.first_name or "Sin nombre"
        
        mensaje = f"""🔍 <b>Información del Chat:</b>

<b>Chat:</b>
• <b>ID:</b> <code>{chat_id}</code>
• <b>Título:</b> {chat_title}
• <b>Tipo:</b> {chat_type}

<b>Usuario:</b>
• <b>ID:</b> <code>{user_id}</code>
• <b>Username:</b> {username}
• <b>Nombre:</b> {first_name}

<b>🧵 Información del Tema:</b>"""
        
        # Verificar si el mensaje tiene message_thread_id (tema específico)
        if update.message and hasattr(update.message, 'message_thread_id') and update.message.message_thread_id:
            thread_id = update.message.message_thread_id
            mensaje += f"""
• <b>ID del Tema:</b> <code>{thread_id}</code>
• <b>Ubicación:</b> Tema específico

<b>✅ Para usar este tema para rutas:</b>
Añade esta línea a tu archivo .env:
<code>RUTAS_THREAD_ID={thread_id}</code>

Luego reinicia el bot."""
        else:
            mensaje += f"""
• <b>ID del Tema:</b> Sin tema (General)
• <b>Ubicación:</b> Tema general del grupo

<b>💡 Para obtener ID de tema específico:</b>
1. Ve al tema "Rutas" en tu grupo
2. Ejecuta <code>/info_chat</code> desde ese tema
3. Copia el ID del tema mostrado"""
        
        mensaje += f"""

<b>🔧 Para configurar como grupo:</b>
Copia este ID del chat y úsalo en .env como GROUP_CHAT_ID"""
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML)

    async def mostrar_rutas(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando /rutas - Muestra todas las rutas disponibles"""
        if not self.can_use_bot(update, only_private=True):
            await update.message.reply_text("❌ Solo puedes ver y gestionar rutas en privado. Escribe al bot directamente.")
            return
            
        try:
            rutas = self.db.obtener_todas_rutas()
            
            if not rutas:
                await update.message.reply_text("❌ No hay rutas disponibles.")
                return
            
            # Verificar límite diario
            hoy = date.today().isoformat()
            # Verificar límite en el grupo configurado, no en el chat actual
            rutas_hoy = self.db.obtener_rutas_del_dia(GROUP_CHAT_ID, hoy)
            
            if len(rutas_hoy) >= MAX_RUTAS_POR_DIA:
                await update.message.reply_text(
                    f"📊 **Límite alcanzado:** Ya se han publicado {MAX_RUTAS_POR_DIA} rutas hoy.\n"
                    f"Usa `/rutas_del_dia` para ver las rutas activas.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Crear botones para seleccionar rutas
            keyboard = []
            for ruta in rutas:
                ruta_id, nombre = ruta['id'], ruta['nombre']
                # Limitar el nombre si es muy largo
                nombre_corto = nombre[:40] + "..." if len(nombre) > 40 else nombre
                button = InlineKeyboardButton(
                    f"🏍️ {nombre_corto}", 
                    callback_data=f"vista_ruta_{ruta_id}"
                )
                keyboard.append([button])
            
            # Agregar botón para volver al menú
            keyboard.append([InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            mensaje = f"""
🏍️ **Rutas Disponibles** ({len(rutas)} rutas) 🏍️

📊 **Publicadas hoy:** {len(rutas_hoy)}/{MAX_RUTAS_POR_DIA}

Selecciona una ruta para ver los detalles:
            """
            
            await update.message.reply_text(
                mensaje, 
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en mostrar_rutas: {e}")
            await update.message.reply_text("❌ Error al cargar las rutas.")

    async def rutas_del_dia(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando /rutas_del_dia - Muestra las rutas publicadas hoy"""
        if not self.can_use_bot(update, only_private=True):
            await update.message.reply_text("❌ Solo puedes ver rutas del día en privado. Escribe al bot directamente.")
            return
            
        try:
            hoy = date.today().isoformat()
            # Siempre buscar en el grupo configurado, no en el chat actual
            rutas_publicadas = self.db.obtener_rutas_del_dia(GROUP_CHAT_ID, hoy)
            
            if not rutas_publicadas:
                mensaje = "📅 **No hay rutas publicadas para hoy.**\n\n¡Usa el menú para explorar rutas disponibles!"
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                if update.message:
                    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)
                elif update.callback_query:
                    await update.callback_query.edit_message_text(mensaje, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)
                return
            
            mensaje = f"📅 **Rutas publicadas hoy** ({len(rutas_publicadas)}) 📅\n\n"
            
            for ruta_pub in rutas_publicadas:
                ruta_id, nombre, dia_ruta, hora_ruta = ruta_pub[1], ruta_pub[8], ruta_pub[4], ruta_pub[5]
                
                # Obtener asistentes
                asistentes = self.db.obtener_asistentes(ruta_pub[0])
                
                mensaje += f"🏍️ **{nombre}**\n"
                mensaje += f"📅 {dia_ruta} ⏰ {hora_ruta}\n"
                mensaje += f"👥 Asistentes: {len(asistentes)}\n\n"
            
            # Agregar botón para volver al menú
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            if update.message:
                await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)
            elif update.callback_query:
                await update.callback_query.edit_message_text(mensaje, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)
            
        except Exception as e:
            logger.error(f"Error en rutas_del_dia: {e}")
            await update.message.reply_text("❌ Error al cargar las rutas del día.")

    async def publicadas(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando /publicadas - Muestra y permite gestionar rutas publicadas"""
        if not self.can_use_bot(update, only_private=True):
            await update.message.reply_text("❌ Solo puedes gestionar rutas publicadas en privado. Escribe al bot directamente.")
            return
            
        try:
            # Siempre buscar en el grupo configurado, no en el chat actual
            rutas_publicadas = self.db.obtener_rutas_publicadas_activas(GROUP_CHAT_ID)
            
            if not rutas_publicadas:
                await update.message.reply_text(
                    "📋 **No hay rutas publicadas actualmente**\n\n"
                    "Usa `/rutas` para publicar nuevas rutas.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            mensaje = f"📋 **Rutas Publicadas** ({len(rutas_publicadas)}) 📋\n\n"
            keyboard = []
            
            for i, ruta_pub in enumerate(rutas_publicadas, 1):
                publicacion_id = ruta_pub['publicacion_id']
                nombre = ruta_pub['nombre']
                dia_ruta = ruta_pub['dia_ruta']
                hora_ruta = ruta_pub['hora_ruta']
                
                # Obtener asistentes
                asistentes = self.db.obtener_asistentes(publicacion_id)
                
                mensaje += f"**{i}.** 🏍️ **{nombre}**\n"
                mensaje += f"📅 {dia_ruta} ⏰ {hora_ruta}\n"
                mensaje += f"👥 Asistentes: {len(asistentes)}\n\n"
                
                # Añadir botón para borrar esta ruta
                keyboard.append([
                    InlineKeyboardButton(
                        f"🗑️ Borrar: {nombre[:20]}{'...' if len(nombre) > 20 else ''}", 
                        callback_data=f"borrar_publicada_{publicacion_id}"
                    )
                ])
            
            # Botón para limpiar todas
            if len(rutas_publicadas) > 1:
                keyboard.append([
                    InlineKeyboardButton(
                        "🧹 Limpiar todas las rutas publicadas", 
                        callback_data="limpiar_todas_publicadas"
                    )
                ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                mensaje, 
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en publicadas: {e}")
            await update.message.reply_text("❌ Error al cargar las rutas publicadas.")

    async def vista_ruta_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Muestra los detalles de la ruta seleccionada para revisión y edición"""
        query = update.callback_query
        await query.answer()
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ La gestión de rutas solo está disponible en privado. Escribe al bot directamente.")
            return
        
        try:
            # Extraer ID de la ruta del callback_data
            ruta_id = int(query.data.split("_")[-1])
            
            # Usar la función auxiliar para mostrar la vista previa
            await self.mostrar_vista_previa_ruta(update, context, ruta_id)
            
        except Exception as e:
            logger.error(f"Error en vista_ruta_callback: {e}")
            await query.edit_message_text("❌ Error al cargar la ruta.")

    async def confirmar_publicar_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Confirma y publica la ruta tal como está"""
        query = update.callback_query
        await query.answer()
        
        try:
            # Extraer ID de la ruta del callback_data
            ruta_id = int(query.data.split("_")[-1])
            
            # Usar la función de publicación directa
            await self.publicar_ruta_directamente(update, context, ruta_id, "✅ **Ruta publicada correctamente**")
            
        except Exception as e:
            logger.error(f"Error en confirmar_publicar_callback: {e}")
            await query.edit_message_text("❌ Error al publicar la ruta.")

    async def editar_encuentro_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite editar el punto de encuentro"""
        query = update.callback_query
        await query.answer()
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ La edición de rutas solo está disponible en privado. Escribe al bot directamente.")
            return
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            
            # Guardar el ruta_id en user_data para usar en el próximo mensaje
            context.user_data['editando_encuentro'] = ruta_id
            
            # Crear botón de cancelar
            keyboard = [[InlineKeyboardButton("❌ Cancelar", callback_data=f"cancelar_encuentro_{ruta_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "📍 **Editar punto de encuentro**\n\n"
                "Envía el nuevo enlace de Google Maps para el punto de encuentro:\n\n"
                "💡 **Cómo obtener el enlace:**\n"
                "1. Abre Google Maps\n"
                "2. Busca el lugar\n"
                "3. Toca 'Compartir' → 'Copiar enlace'\n"
                "4. Pégalo aquí\n\n"
                "O usa el botón de abajo para cancelar:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logger.error(f"Error en editar_encuentro_callback: {e}")
            await query.edit_message_text("❌ Error al editar punto de encuentro.")

    async def editar_restaurante_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite editar el restaurante"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            
            # Guardar el ruta_id en user_data para usar en el próximo mensaje
            context.user_data['editando_restaurante'] = ruta_id
            
            # Crear botón de cancelar
            keyboard = [[InlineKeyboardButton("❌ Cancelar", callback_data=f"cancelar_restaurante_{ruta_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🍽️ **Editar restaurante**\n\n"
                "Envía el nuevo enlace de Google Maps para el restaurante:\n\n"
                "💡 **Cómo obtener el enlace:**\n"
                "1. Abre Google Maps\n"
                "2. Busca el restaurante\n"
                "3. Toca 'Compartir' → 'Copiar enlace'\n"
                "4. Pégalo aquí\n\n"
                "O usa el botón de abajo para cancelar:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logger.error(f"Error en editar_restaurante_callback: {e}")
            await query.edit_message_text("❌ Error al editar restaurante.")

    async def editar_fecha_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite editar la fecha de la ruta con calendario"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            
            # Mostrar calendario del mes actual
            today = date.today()
            keyboard = self.generar_calendario(today.year, today.month, ruta_id)
            
            await query.edit_message_text(
                "📅 **Selecciona la fecha de la ruta**\n\n"
                "Usa el calendario para seleccionar una fecha o escribe manualmente:",
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en editar_fecha_callback: {e}")
            await query.edit_message_text("❌ Error al editar fecha.")

    async def editar_hora_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite editar la hora de la ruta con selector"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            
            # Mostrar selector de hora
            keyboard = self.generar_selector_hora(ruta_id)
            
            await query.edit_message_text(
                "⏰ **Selecciona la hora de la ruta**\n\n"
                "Elige una hora común o escribe manualmente:",
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en editar_hora_callback: {e}")
            await query.edit_message_text("❌ Error al editar hora.")

    async def calendario_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja las interacciones del calendario"""
        query = update.callback_query
        await query.answer()
        
        try:
            data = query.data.split("_")
            action = data[1]  # prev, next, select
            ruta_id = int(data[2])
            
            if action == "prev":
                year, month = int(data[3]), int(data[4])
                # Mes anterior
                if month == 1:
                    month, year = 12, year - 1
                else:
                    month -= 1
                    
                keyboard = self.generar_calendario(year, month, ruta_id)
                await query.edit_message_reply_markup(reply_markup=keyboard)
                
            elif action == "next":
                year, month = int(data[3]), int(data[4])
                # Mes siguiente
                if month == 12:
                    month, year = 1, year + 1
                else:
                    month += 1
                    
                keyboard = self.generar_calendario(year, month, ruta_id)
                await query.edit_message_reply_markup(reply_markup=keyboard)
                
            elif action == "select":
                year, month, day = int(data[3]), int(data[4]), int(data[5])
                fecha_seleccionada = date(year, month, day)
                fecha_texto = fecha_seleccionada.strftime("%d/%m/%Y")
                
                # Actualizar en la base de datos
                self.db.actualizar_fecha_ruta(ruta_id, fecha_texto)
                
                # Mostrar vista previa actualizada
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    f"✅ **Fecha actualizada a {fecha_texto}**"
                )
                
        except Exception as e:
            logger.error(f"Error en calendario_callback: {e}")
            await query.edit_message_text("❌ Error procesando fecha.")

    async def hora_selector_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja la selección de hora"""
        query = update.callback_query
        await query.answer()
        
        try:
            data = query.data.split("_")
            action = data[1]  # select
            ruta_id = int(data[2])
            
            if action == "select":
                hora_seleccionada = data[3]
                
                # Actualizar en la base de datos
                self.db.actualizar_hora_ruta(ruta_id, hora_seleccionada)
                
                # Mostrar vista previa actualizada
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    f"✅ **Hora actualizada a {hora_seleccionada}**"
                )
                
        except Exception as e:
            logger.error(f"Error en hora_selector_callback: {e}")
            await query.edit_message_text("❌ Error procesando hora.")

    async def fecha_manual_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite escribir fecha manualmente"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            context.user_data['editando_fecha'] = ruta_id
            
            await query.edit_message_text(
                "📅 **Escribe la fecha manualmente**\n\n"
                "💡 **Ejemplos:**\n"
                "• 15/09/2024\n"
                "• Sábado 15 de septiembre\n"
                "• Este fin de semana\n\n"
                "O envía /cancelar para volver atrás",
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en fecha_manual_callback: {e}")
            await query.edit_message_text("❌ Error.")

    async def hora_manual_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Permite escribir hora manualmente"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            context.user_data['editando_hora'] = ruta_id
            
            await query.edit_message_text(
                "⏰ **Escribe la hora manualmente**\n\n"
                "💡 **Ejemplos:**\n"
                "• 09:00\n"
                "• 9:30 de la mañana\n"
                "• Salida 8:30, encuentro 9:00\n\n"
                "O envía /cancelar para volver atrás",
                parse_mode=ParseMode.MARKDOWN
            )
            
        except Exception as e:
            logger.error(f"Error en hora_manual_callback: {e}")
            await query.edit_message_text("❌ Error.")

    async def volver_rutas_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Vuelve a mostrar la lista de rutas"""
        query = update.callback_query
        await query.answer()
        
        # Usar la versión callback de mostrar rutas
        await self._mostrar_rutas_callback(update, context)

    async def cancelar_publicacion_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela la publicación de la ruta"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text("❌ Publicación cancelada.")

    async def borrar_publicada_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja el borrado de una ruta publicada específica"""
        query = update.callback_query
        await query.answer()
        
        # Extraer el ID de la publicación del callback_data
        publicacion_id = int(query.data.replace("borrar_publicada_", ""))
        
        try:
            # Obtener información de la publicación antes de borrarla
            # Siempre buscar en el grupo configurado, no en el chat actual
            rutas_publicadas = self.db.obtener_rutas_publicadas_activas(GROUP_CHAT_ID)
            
            # Buscar la publicación específica
            publicacion = None
            for ruta_pub in rutas_publicadas:
                if ruta_pub['publicacion_id'] == publicacion_id:
                    publicacion = ruta_pub
                    break
            
            if not publicacion:
                await query.edit_message_text("❌ Ruta publicada no encontrada.")
                return
            
            # Obtener información del mensaje para eliminarlo del grupo
            message_id_grupo = publicacion.get('message_id')
            chat_id_grupo = publicacion.get('chat_id')
            
            # Desactivar la ruta publicada en la base de datos
            success = self.db.desactivar_ruta_publicada(publicacion_id)
            
            if success:
                # Intentar eliminar el mensaje del grupo
                mensaje_eliminado = False
                if message_id_grupo and chat_id_grupo:
                    try:
                        await context.bot.delete_message(
                            chat_id=chat_id_grupo,
                            message_id=message_id_grupo
                        )
                        mensaje_eliminado = True
                        logger.info(f"Mensaje de ruta eliminado del grupo: {message_id_grupo}")
                    except Exception as e:
                        logger.warning(f"No se pudo eliminar el mensaje del grupo: {e}")
                
                # Crear mensaje de confirmación
                mensaje = f"✅ **Ruta eliminada correctamente:**\n"
                mensaje += f"🏍️ **{publicacion['nombre']}**\n"
                if publicacion.get('dia_ruta'):
                    mensaje += f"📅 {publicacion['dia_ruta']}\n"
                if publicacion.get('hora_ruta'):
                    mensaje += f"⏰ {publicacion['hora_ruta']}\n"
                
                if mensaje_eliminado:
                    mensaje += f"\n🗑️ **Eliminado también del grupo**"
                else:
                    mensaje += f"\n⚠️ **Eliminado de la base de datos** (el mensaje del grupo puede requerir eliminación manual)"
                
                mensaje += f"\n\n🔄 Para ver las rutas restantes, usa /publicadas"
                
                await query.edit_message_text(mensaje, parse_mode='Markdown')
            else:
                await query.edit_message_text("❌ Error al eliminar la ruta. Inténtalo de nuevo.")
                
        except Exception as e:
            print(f"Error al borrar ruta publicada: {e}")
            await query.edit_message_text("❌ Error al eliminar la ruta. Inténtalo de nuevo.")

    async def limpiar_todas_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja la limpieza masiva de todas las rutas publicadas"""
        query = update.callback_query
        await query.answer()
        
        try:
            # Siempre usar el grupo configurado, no el chat actual
            # Obtener rutas activas antes de limpiar para eliminar mensajes
            rutas_activas = self.db.obtener_rutas_publicadas_activas(GROUP_CHAT_ID)
            cantidad = len(rutas_activas)
            
            if cantidad == 0:
                await query.edit_message_text("ℹ️ No hay rutas publicadas activas para eliminar.")
                return
            
            # Intentar eliminar todos los mensajes del grupo antes de limpiar la base de datos
            mensajes_eliminados = 0
            for ruta in rutas_activas:
                message_id_grupo = ruta.get('message_id')
                chat_id_grupo = ruta.get('chat_id')
                
                if message_id_grupo and chat_id_grupo:
                    try:
                        await context.bot.delete_message(
                            chat_id=chat_id_grupo,
                            message_id=message_id_grupo
                        )
                        mensajes_eliminados += 1
                        logger.info(f"Mensaje de ruta eliminado del grupo: {message_id_grupo}")
                    except Exception as e:
                        logger.warning(f"No se pudo eliminar mensaje {message_id_grupo}: {e}")
            
            # Limpiar todas las rutas en la base de datos
            success = self.db.limpiar_todas_rutas_publicadas(GROUP_CHAT_ID)
            
            if success:
                mensaje = f"🧹 **Limpieza completada:**\n"
                mensaje += f"✅ Se eliminaron **{cantidad}** rutas publicadas\n"
                mensaje += f"🗑️ **{mensajes_eliminados}** mensajes eliminados del grupo\n"
                if mensajes_eliminados < cantidad:
                    mensaje += f"⚠️ **{cantidad - mensajes_eliminados}** mensajes no se pudieron eliminar automáticamente\n"
                mensaje += f"📊 Total de rutas procesadas: {cantidad}\n"
                mensaje += f"\n🔄 Ahora puedes publicar nuevas rutas sin límite"
                
                await query.edit_message_text(mensaje, parse_mode='Markdown')
            else:
                await query.edit_message_text("❌ Error al limpiar las rutas. Inténtalo de nuevo.")
                
        except Exception as e:
            print(f"Error al limpiar todas las rutas: {e}")
            await query.edit_message_text("❌ Error al limpiar las rutas. Inténtalo de nuevo.")

    async def apuntar_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja cuando un usuario se apunta a una ruta"""
        query = update.callback_query
        
        try:
            # Extraer el ID de la publicación del callback_data
            publicacion_id = int(query.data.replace("apuntar_", ""))
            user_id = query.from_user.id
            username = query.from_user.username or query.from_user.first_name
            
            # Añadir asistente
            success = self.db.agregar_asistente(publicacion_id, user_id, username)
            
            if success:
                # Actualizar mensaje con lista de asistentes actualizada
                await self.actualizar_mensaje_asistentes_botones(query.message.chat.id, query.message.message_id, publicacion_id, context)
                await query.answer("✅ Te has apuntado a la ruta!", show_alert=True)
            else:
                await query.answer("ℹ️ Ya estás apuntado a esta ruta", show_alert=True)
                
        except Exception as e:
            print(f"Error al apuntar usuario: {e}")
            await query.answer("❌ Error al apuntarte. Inténtalo de nuevo.", show_alert=True)

    async def desapuntar_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja cuando un usuario se desapunta de una ruta"""
        query = update.callback_query
        
        try:
            # Extraer el ID de la publicación del callback_data
            publicacion_id = int(query.data.replace("desapuntar_", ""))
            user_id = query.from_user.id
            
            # Quitar asistente
            success = self.db.quitar_asistente(publicacion_id, user_id)
            
            if success:
                # Actualizar mensaje con lista de asistentes actualizada
                await self.actualizar_mensaje_asistentes_botones(query.message.chat.id, query.message.message_id, publicacion_id, context)
                await query.answer("✅ Te has desapuntado de la ruta!", show_alert=True)
            else:
                await query.answer("ℹ️ No estabas apuntado a esta ruta", show_alert=True)
                
        except Exception as e:
            print(f"Error al desapuntar usuario: {e}")
            await query.answer("❌ Error al desapuntarte. Inténtalo de nuevo.", show_alert=True)

    async def actualizar_mensaje_asistentes_botones(self, chat_id: int, message_id: int, publicacion_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Actualiza el mensaje de la ruta con la lista actualizada de asistentes usando botones"""
        try:
            # Obtener información de la publicación
            publicacion = self.db.obtener_publicacion_por_mensaje(chat_id, message_id)
            if not publicacion:
                return
                
            # Obtener información de la ruta
            ruta = self.db.obtener_ruta(publicacion['ruta_id'])
            if not ruta:
                return
            
            # Obtener asistentes actualizados
            asistentes = self.db.obtener_asistentes(publicacion_id)
            cantidad_asistentes = len(asistentes)
            
            # Construir mensaje actualizado (usando HTML en lugar de Markdown)
            mensaje = f"🏍️ <b>{publicacion['nombre']}</b>\n\n"
            
            # Usar fecha y hora actualizadas de la tabla rutas (si existen) o las originales de la publicación
            fecha_mostrar = publicacion.get('fecha') or publicacion.get('dia_ruta')
            hora_mostrar = publicacion.get('hora') or publicacion.get('hora_ruta')
            
            if fecha_mostrar:
                mensaje += f"📅 <b>Fecha:</b> {fecha_mostrar}\n"
            if hora_mostrar:
                mensaje += f"⏰ <b>Hora:</b> {hora_mostrar}\n"
            
            # Enlace de encuentro personalizado o por defecto
            if publicacion.get('link_encuentro_personalizado'):
                mensaje += f"📍 <b>Encuentro:</b> {publicacion['link_encuentro_personalizado']}\n"
            else:
                if ruta.get('link_encuentro'):
                    mensaje += f"📍 <b>Encuentro:</b> {ruta['link_encuentro']}\n"
            
            mensaje += f"🗺️ <b>Ruta:</b> {ruta['link_ruta']}\n"
            
            # Información de restaurante si existe
            if ruta.get('link_restaurante'):
                mensaje += f"🍽️ <b>Restaurante:</b> {ruta['link_restaurante']}\n"
            
            mensaje += f"\n👥 <b>Asistentes: {cantidad_asistentes}</b>\n"
            
            if asistentes:
                for i, asistente in enumerate(asistentes, 1):
                    username = asistente['username'] or f"Usuario {asistente['user_id']}"
                    mensaje += f"{i}. {username}\n"
            else:
                mensaje += "<i>No hay asistentes aún</i>\n"
            
            mensaje += "\n💡 <b>Usa los botones para apuntarte o desapuntarte</b>"
            
            # Mantener los botones
            keyboard = [
                [
                    InlineKeyboardButton("👍 Apuntarme", callback_data=f"apuntar_{publicacion_id}"),
                    InlineKeyboardButton("👎 Desapuntarme", callback_data=f"desapuntar_{publicacion_id}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Actualizar el mensaje
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=mensaje,
                parse_mode='HTML',
                disable_web_page_preview=True,
                reply_markup=reply_markup
            )
            
        except Exception as e:
            print(f"Error actualizando mensaje de asistentes: {e}")

    async def manejar_mensajes_texto(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja mensajes de texto para edición de encuentros y restaurantes"""
        if not self.can_use_bot(update, only_private=True):
            return
            
        user_data = context.user_data
        
        # Verificar si está en proceso de añadir ruta
        if 'anadir_ruta' in user_data:
            await self._procesar_anadir_ruta_texto(update, context)
            return
        
        # Verificar si está editando punto de encuentro
        if 'editando_encuentro' in user_data:
            ruta_id = user_data.pop('editando_encuentro')
            nuevo_enlace = update.message.text.strip()
            
            if nuevo_enlace.lower() == '/cancelar':
                # Mostrar vista previa de nuevo
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "❌ **Edición de punto de encuentro cancelada**"
                )
                return
            
            # Validar que sea un enlace de Google Maps
            if 'google.com/maps' not in nuevo_enlace and 'goo.gl' not in nuevo_enlace:
                await update.message.reply_text(
                    "❌ Por favor, envía un enlace válido de Google Maps.\n"
                    "O envía /cancelar para cancelar."
                )
                context.user_data['editando_encuentro'] = ruta_id  # Volver a poner el estado
                return
            
            # Actualizar en la base de datos
            try:
                self.db.actualizar_punto_encuentro_personalizado(ruta_id, nuevo_enlace)
                
                # Mostrar vista previa actualizada para permitir más ediciones
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "✅ **Punto de encuentro actualizado correctamente**"
                )
                
            except Exception as e:
                logger.error(f"Error actualizando punto de encuentro: {e}")
                await update.message.reply_text("❌ Error al actualizar el punto de encuentro.")
        
        # Verificar si está editando restaurante
        elif 'editando_restaurante' in user_data:
            ruta_id = user_data.pop('editando_restaurante')
            nuevo_enlace = update.message.text.strip()
            
            if nuevo_enlace.lower() == '/cancelar':
                # Mostrar vista previa de nuevo
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "❌ **Edición de restaurante cancelada**"
                )
                return
            
            # Validar que sea un enlace de Google Maps
            if 'google.com/maps' not in nuevo_enlace and 'goo.gl' not in nuevo_enlace:
                await update.message.reply_text(
                    "❌ Por favor, envía un enlace válido de Google Maps.\n"
                    "O envía /cancelar para cancelar."
                )
                context.user_data['editando_restaurante'] = ruta_id  # Volver a poner el estado
                return
            
            # Actualizar en la base de datos
            try:
                self.db.actualizar_restaurante_personalizado(ruta_id, nuevo_enlace)
                
                # Mostrar vista previa actualizada para permitir más ediciones
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "✅ **Restaurante actualizado correctamente**"
                )
                
            except Exception as e:
                logger.error(f"Error actualizando restaurante: {e}")
                await update.message.reply_text("❌ Error al actualizar el restaurante.")

        # Verificar si está editando fecha
        elif 'editando_fecha' in user_data:
            ruta_id = user_data.pop('editando_fecha')
            nueva_fecha = update.message.text.strip()
            
            if nueva_fecha.lower() == '/cancelar':
                # Mostrar vista previa de nuevo
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "❌ **Edición de fecha cancelada**"
                )
                return
            
            # Actualizar en la base de datos
            try:
                self.db.actualizar_fecha_ruta(ruta_id, nueva_fecha)
                
                # Mostrar vista previa actualizada para permitir más ediciones
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "✅ **Fecha actualizada correctamente**"
                )
                
            except Exception as e:
                logger.error(f"Error actualizando fecha: {e}")
                await update.message.reply_text("❌ Error al actualizar la fecha.")

        # Verificar si está editando hora
        elif 'editando_hora' in user_data:
            ruta_id = user_data.pop('editando_hora')
            nueva_hora = update.message.text.strip()
            
            if nueva_hora.lower() == '/cancelar':
                # Mostrar vista previa de nuevo
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "❌ **Edición de hora cancelada**"
                )
                return
            
            # Actualizar en la base de datos
            try:
                self.db.actualizar_hora_ruta(ruta_id, nueva_hora)
                
                # Mostrar vista previa actualizada para permitir más ediciones
                await self.mostrar_vista_previa_ruta(
                    update, context, ruta_id, 
                    "✅ **Hora actualizada correctamente**"
                )
                
            except Exception as e:
                logger.error(f"Error actualizando hora: {e}")
                await update.message.reply_text("❌ Error al actualizar la hora.")

    async def cancelar_encuentro_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela la edición del punto de encuentro y vuelve a la vista previa"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            # Limpiar estado de edición
            if 'editando_encuentro' in context.user_data:
                del context.user_data['editando_encuentro']
            
            # Volver a la vista previa
            await self.mostrar_vista_previa_ruta(update, context, ruta_id)
        except Exception as e:
            logger.error(f"Error en cancelar_encuentro_callback: {e}")
            await query.edit_message_text("❌ Error al cancelar edición.")

    async def cancelar_restaurante_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela la edición del restaurante y vuelve a la vista previa"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            # Limpiar estado de edición
            if 'editando_restaurante' in context.user_data:
                del context.user_data['editando_restaurante']
            
            # Volver a la vista previa
            await self.mostrar_vista_previa_ruta(update, context, ruta_id)
        except Exception as e:
            logger.error(f"Error en cancelar_restaurante_callback: {e}")
            await query.edit_message_text("❌ Error al cancelar edición.")

    async def cancelar_fecha_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela la edición de fecha y vuelve a la vista previa"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            # Volver a la vista previa
            await self.mostrar_vista_previa_ruta(update, context, ruta_id)
        except Exception as e:
            logger.error(f"Error en cancelar_fecha_callback: {e}")
            await query.edit_message_text("❌ Error al cancelar edición.")

    async def cancelar_hora_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela la edición de hora y vuelve a la vista previa"""
        query = update.callback_query
        await query.answer()
        
        try:
            ruta_id = int(query.data.split("_")[-1])
            # Volver a la vista previa
            await self.mostrar_vista_previa_ruta(update, context, ruta_id)
        except Exception as e:
            logger.error(f"Error en cancelar_hora_callback: {e}")
            await query.edit_message_text("❌ Error al cancelar edición.")

    async def mostrar_vista_previa_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE, ruta_id: int, mensaje_previo: str = "") -> None:
        """Función auxiliar para mostrar la vista previa de una ruta con opciones para editar"""
        try:
            # Obtener información de la ruta
            ruta = self.db.obtener_ruta(ruta_id)
            if not ruta:
                mensaje_error = "❌ Error: Ruta no encontrada."
                if update.callback_query:
                    await update.callback_query.answer()
                    await update.callback_query.message.reply_text(mensaje_error)
                else:
                    await update.message.reply_text(mensaje_error)
                return
            
            # Información de la ruta (siempre debe ser un diccionario)
            nombre = ruta.get('nombre', 'Sin nombre')
            link_ruta = ruta.get('link_ruta', '')
            link_encuentro_default = ruta.get('link_encuentro', '')
            link_restaurante_default = ruta.get('link_restaurante', '')
            fecha_ruta = ruta.get('fecha', 'Por definir')
            hora_ruta = ruta.get('hora', 'Por confirmar')
            
            # Manejar restaurante
            if link_restaurante_default:
                restaurante_texto = f"[Ver ubicación]({link_restaurante_default})"
            else:
                restaurante_texto = "No configurado"
            
            # Crear mensaje de vista previa
            mensaje = f"""🏍️ **VISTA PREVIA DE LA RUTA**

📋 **Nombre:** {nombre}

🛣️ **Ruta:** [Ver en Google Maps]({link_ruta})

📍 **Punto de encuentro:** [Ver ubicación]({link_encuentro_default})

🍽️ **Restaurante:** {restaurante_texto}

📅 **Fecha:** {fecha_ruta}
⏰ **Hora:** {hora_ruta}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**¿Qué quieres hacer?**"""
            
            if mensaje_previo:
                mensaje = f"{mensaje_previo}\n\n{mensaje}"
            
            # Crear botones de acción
            keyboard = [
                [InlineKeyboardButton("✅ Publicar tal como está", callback_data=f"confirmar_publicar_{ruta_id}")],
                [InlineKeyboardButton("📍 Editar Punto de Encuentro", callback_data=f"editar_encuentro_{ruta_id}")],
                [InlineKeyboardButton("🍽️ Editar Restaurante", callback_data=f"editar_restaurante_{ruta_id}")],
                [InlineKeyboardButton("📅 Editar Fecha", callback_data=f"editar_fecha_{ruta_id}")],
                [InlineKeyboardButton("⏰ Editar Hora", callback_data=f"editar_hora_{ruta_id}")],
                [InlineKeyboardButton("🔙 Volver a rutas", callback_data="volver_rutas")],
                [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_publicacion")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Enviar mensaje (puede venir de callback o mensaje directo)
            if update.callback_query:
                await update.callback_query.answer()
                await update.callback_query.edit_message_text(
                    mensaje,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            else:
                await update.message.reply_text(
                    mensaje,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            
        except Exception as e:
            logger.error(f"Error en mostrar_vista_previa_ruta: {e}")
            mensaje_error = "❌ Error al cargar la vista previa de la ruta."
            if update.callback_query:
                await update.callback_query.answer()
                await update.callback_query.message.reply_text(mensaje_error)
            else:
                await update.message.reply_text(mensaje_error)

    async def publicar_en_grupo(self, context: ContextTypes.DEFAULT_TYPE, ruta_id: int) -> tuple:
        """Publica una ruta en el grupo configurado desde cualquier contexto"""
        try:
            # Verificar límite diario en el grupo objetivo
            hoy = date.today().isoformat()
            chat_id = GROUP_CHAT_ID
            rutas_hoy = self.db.obtener_rutas_del_dia(chat_id, hoy)
            
            if len(rutas_hoy) >= MAX_RUTAS_POR_DIA:
                return None, False, f"❌ Límite alcanzado: Ya se han publicado {MAX_RUTAS_POR_DIA} rutas hoy."
            
            # Obtener información de la ruta
            ruta = self.db.obtener_ruta(ruta_id)
            if not ruta:
                return None, False, "❌ Error: Ruta no encontrada."
            
            # Información de la ruta
            nombre = ruta['nombre']
            link_ruta = ruta['link_ruta']
            link_encuentro_efectivo = self.db.obtener_link_encuentro_efectivo(ruta_id)
            link_restaurante = ruta['link_restaurante']
            fecha_ruta = ruta.get('fecha', date.today().strftime('%d/%m/%Y'))
            hora_ruta = ruta.get('hora', 'Por confirmar')
            
            # Crear mensaje de la ruta publicada
            mensaje_ruta = f"""🏍️ **{nombre}**

📅 **Fecha:** {fecha_ruta}
⏰ **Hora:** {hora_ruta}

📍 **Encuentro:** [Ver ubicación]({link_encuentro_efectivo})
🗺️ **Ruta:** [Ver en Google Maps]({link_ruta})"""
            
            if link_restaurante:
                mensaje_ruta += f"\n🍽️ **Restaurante:** [Ver ubicación]({link_restaurante})"
            
            mensaje_ruta += f"""

👥 **Asistentes: 0**
_No hay asistentes aún_

💡 **Reacciona con 👍 para apuntarte o quítala para desapuntarte**"""
            
            # Enviar mensaje al grupo
            mensaje_enviado = await self._send_message_to_group(
                context,
                mensaje_ruta,
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True
            )
            
            # Guardar en base de datos
            message_id = mensaje_enviado.message_id
            resultado = self.db.publicar_ruta(
                ruta_id=ruta_id,
                message_id=message_id,
                chat_id=chat_id,
                dia_ruta=hoy,
                hora_ruta=hora_ruta
            )
            
            # Extraer el publicacion_id de la tupla
            publicacion_id, success, error = resultado
            
            if success and publicacion_id:
                # Crear botones para apuntarse/desapuntarse
                keyboard = [
                    [
                        InlineKeyboardButton("👍 Apuntarme", callback_data=f"apuntar_{publicacion_id}"),
                        InlineKeyboardButton("👎 Desapuntarme", callback_data=f"desapuntar_{publicacion_id}")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                # Actualizar mensaje con botones
                await context.bot.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=message_id,
                    reply_markup=reply_markup
                )
                
                logger.info(f"Ruta {nombre} publicada exitosamente en grupo con ID {publicacion_id}")
                return publicacion_id, True, f"✅ ¡Ruta **{nombre}** publicada exitosamente en el grupo!"
            else:
                return None, False, "⚠️ La ruta se envió pero hubo un problema guardándola en la base de datos."
                
        except Exception as e:
            logger.error(f"Error en publicar_en_grupo: {e}")
            return None, False, "❌ Error al publicar la ruta."

    async def publicar_ruta_directamente(self, update: Update, context: ContextTypes.DEFAULT_TYPE, ruta_id: int, mensaje_exito: str) -> None:
        """Publica una ruta directamente sin confirmación adicional"""
        try:
            # Si estamos en chat privado, publicar en el grupo configurado
            chat_id = update.effective_chat.id
            if chat_id > 0:  # Chat privado
                publicacion_id, success, mensaje = await self.publicar_en_grupo(context, ruta_id)
                
                if success:
                    mensaje_confirmacion = f"{mensaje_exito}\n\n{mensaje}"
                    if update.callback_query:
                        await update.callback_query.edit_message_text(mensaje_confirmacion, parse_mode=ParseMode.MARKDOWN)
                    else:
                        await update.message.reply_text(mensaje_confirmacion, parse_mode=ParseMode.MARKDOWN)
                else:
                    if update.callback_query:
                        await update.callback_query.edit_message_text(mensaje)
                    else:
                        await update.message.reply_text(mensaje)
                return
            
            # Si estamos en el grupo, usar el comportamiento original
            # Verificar límite diario
            hoy = date.today().isoformat()
            rutas_hoy = self.db.obtener_rutas_del_dia(chat_id, hoy)
            
            if len(rutas_hoy) >= MAX_RUTAS_POR_DIA:
                mensaje_error = f"❌ Límite alcanzado: Ya se han publicado {MAX_RUTAS_POR_DIA} rutas hoy."
                if update.callback_query:
                    await update.callback_query.edit_message_text(mensaje_error)
                else:
                    await update.message.reply_text(mensaje_error)
                return
            
            # Obtener información de la ruta actualizada
            ruta = self.db.obtener_ruta(ruta_id)
            if not ruta:
                mensaje_error = "❌ Error: Ruta no encontrada."
                if update.callback_query:
                    await update.callback_query.edit_message_text(mensaje_error)
                else:
                    await update.message.reply_text(mensaje_error)
                return
            
            # Información de la ruta (siempre debe ser un diccionario)
            nombre = ruta['nombre']
            link_ruta = ruta['link_ruta']
            link_encuentro_efectivo = self.db.obtener_link_encuentro_efectivo(ruta_id)
            link_restaurante = ruta['link_restaurante']
            fecha_ruta = ruta.get('fecha', date.today().strftime('%d/%m/%Y'))
            hora_ruta = ruta.get('hora', 'Por confirmar')
            
            # Crear mensaje de la ruta publicada
            mensaje_ruta = f"""🏍️ **{nombre}**

� **Fecha:** {fecha_ruta}
⏰ **Hora:** {hora_ruta}

📍 **Encuentro:** [Ver ubicación]({link_encuentro_efectivo})
🗺️ **Ruta:** [Ver en Google Maps]({link_ruta})"""
            
            if link_restaurante:
                mensaje_ruta += f"\n🍽️ **Restaurante:** [Ver ubicación]({link_restaurante})"
            
            mensaje_ruta += f"""

� **Asistentes: 0**
_No hay asistentes aún_

💡 **Reacciona con 👍 para apuntarte o quítala para desapuntarte**"""
            
            # Enviar mensaje de la ruta al grupo
            if str(chat_id) == str(GROUP_CHAT_ID):
                # Si estamos en el grupo configurado, usar la función con soporte para temas
                mensaje_enviado = await self._send_message_to_group(
                    context,
                    mensaje_ruta,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            else:
                # Si es otro grupo, enviar normalmente
                mensaje_enviado = await context.bot.send_message(
                    chat_id=chat_id,
                    text=mensaje_ruta,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            
            # Guardar en base de datos
            message_id = mensaje_enviado.message_id
            
            resultado = self.db.publicar_ruta(
                ruta_id=ruta_id,
                message_id=message_id,
                chat_id=chat_id,
                dia_ruta=hoy,
                hora_ruta=hora_ruta
            )
            
            # Extraer el publicacion_id de la tupla
            publicacion_id, success, error = resultado
            
            if success and publicacion_id:
                # Crear botones para apuntarse/desapuntarse
                keyboard = [
                    [
                        InlineKeyboardButton("👍 Apuntarme", callback_data=f"apuntar_{publicacion_id}"),
                        InlineKeyboardButton("👎 Desapuntarme", callback_data=f"desapuntar_{publicacion_id}")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                # Actualizar mensaje con botones
                await context.bot.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=message_id,
                    reply_markup=reply_markup
                )
            
            if publicacion_id:
                logger.info(f"Ruta {nombre} publicada exitosamente con ID {publicacion_id}")
                
                # Confirmar al usuario
                mensaje_confirmacion = f"{mensaje_exito}\n\n✅ ¡Ruta **{nombre}** publicada exitosamente!"
                if update.callback_query:
                    await update.callback_query.edit_message_text(mensaje_confirmacion, parse_mode=ParseMode.MARKDOWN)
                else:
                    await update.message.reply_text(mensaje_confirmacion, parse_mode=ParseMode.MARKDOWN)
            else:
                mensaje_error = "⚠️ La ruta se envió pero hubo un problema guardándola en la base de datos."
                if update.callback_query:
                    await update.callback_query.edit_message_text(mensaje_error)
                else:
                    await update.message.reply_text(mensaje_error)
                
        except Exception as e:
            logger.error(f"Error en publicar_ruta_directamente: {e}")
            mensaje_error = "❌ Error al publicar la ruta."
            if update.callback_query:
                await update.callback_query.edit_message_text(mensaje_error)
            else:
                await update.message.reply_text(mensaje_error)

    def generar_calendario(self, year: int, month: int, ruta_id: int) -> InlineKeyboardMarkup:
        """Genera un calendario inline para seleccionar fecha"""
        # Nombres de los meses en español
        meses = [
            "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
        ]
        
        # Días de la semana
        dias_semana = ["L", "M", "X", "J", "V", "S", "D"]
        
        # Obtener calendario del mes
        cal = calendar.monthcalendar(year, month)
        
        keyboard = []
        
        # Header con mes y año
        keyboard.append([
            InlineKeyboardButton("◀", callback_data=f"cal_prev_{ruta_id}_{year}_{month}"),
            InlineKeyboardButton(f"{meses[month]} {year}", callback_data="ignore"),
            InlineKeyboardButton("▶", callback_data=f"cal_next_{ruta_id}_{year}_{month}")
        ])
        
        # Días de la semana
        keyboard.append([InlineKeyboardButton(dia, callback_data="ignore") for dia in dias_semana])
        
        # Días del mes
        today = date.today()
        for week in cal:
            row = []
            for day in week:
                if day == 0:
                    row.append(InlineKeyboardButton(" ", callback_data="ignore"))
                else:
                    fecha_actual = date(year, month, day)
                    if fecha_actual < today:
                        # Días pasados en gris
                        row.append(InlineKeyboardButton(f"✖{day}", callback_data="ignore"))
                    else:
                        # Días disponibles
                        row.append(InlineKeyboardButton(str(day), callback_data=f"cal_select_{ruta_id}_{year}_{month}_{day}"))
            keyboard.append(row)
        
        # Opciones adicionales
        keyboard.append([
            InlineKeyboardButton("📝 Escribir fecha manualmente", callback_data=f"fecha_manual_{ruta_id}"),
            InlineKeyboardButton("❌ Cancelar", callback_data=f"cancelar_fecha_{ruta_id}")
        ])
        
        return InlineKeyboardMarkup(keyboard)

    def generar_menu_principal(self, user_id: int = None) -> InlineKeyboardMarkup:
        """Genera el menú principal con botones para comandos frecuentes"""
        keyboard = []
        
        # Primera fila: Comandos principales
        keyboard.append([
            InlineKeyboardButton("🏍️ Ver Rutas", callback_data="menu_rutas"),
            InlineKeyboardButton("📋 Rutas del Día", callback_data="menu_rutas_del_dia")
        ])
        
        # Segunda fila: Gestión (disponible para todos)
        keyboard.append([
            InlineKeyboardButton("⚙️ Gestionar Publicadas", callback_data="menu_publicadas"),
            InlineKeyboardButton("➕ Añadir Ruta", callback_data="menu_anadir_ruta")
        ])
        
        # Tercera fila: Ayuda
        keyboard.append([
            InlineKeyboardButton("❓ Ayuda", callback_data="menu_ayuda")
        ])
        
        return InlineKeyboardMarkup(keyboard)

    async def mostrar_menu_principal(self, update: Update, context: ContextTypes.DEFAULT_TYPE, mensaje_personalizado: str = None) -> None:
        """Muestra el menú principal con botones"""
        if not self.can_use_bot(update, only_private=True):
            return
        
        user_id = update.effective_user.id if update.effective_user else None
        
        mensaje = mensaje_personalizado or """
🏍️ **MENÚ PRINCIPAL - Bot de Rutas Moteras** 🏍️

Usa los botones de abajo para navegar:
        """
        
        keyboard = self.generar_menu_principal(user_id)
        
        if update.message:
            await update.message.reply_text(
                mensaje, 
                parse_mode='Markdown',
                reply_markup=keyboard
            )
        elif update.callback_query:
            await update.callback_query.edit_message_text(
                mensaje,
                parse_mode='Markdown',
                reply_markup=keyboard
            )

    def generar_selector_hora(self, ruta_id: int) -> InlineKeyboardMarkup:
        """Genera un selector de hora inline"""
        keyboard = []
        
        # Horas populares para rutas moteras
        horas_populares = [
            ("🌅 08:00", "08:00"),
            ("☀️ 09:00", "09:00"),
            ("🕘 09:30", "09:30"),
            ("🕙 10:00", "10:00"),
            ("🕥 10:30", "10:30"),
            ("🕦 11:00", "11:00")
        ]
        
        # Añadir horas en filas de 2
        for i in range(0, len(horas_populares), 2):
            row = []
            for j in range(2):
                if i + j < len(horas_populares):
                    emoji_hora, hora = horas_populares[i + j]
                    row.append(InlineKeyboardButton(emoji_hora, callback_data=f"hora_select_{ruta_id}_{hora}"))
            keyboard.append(row)
        
        # Opciones adicionales
        keyboard.append([
            InlineKeyboardButton("📝 Escribir hora manualmente", callback_data=f"hora_manual_{ruta_id}"),
        ])
        
        keyboard.append([
            InlineKeyboardButton("❌ Cancelar", callback_data=f"cancelar_hora_{ruta_id}")
        ])
        
        return InlineKeyboardMarkup(keyboard)

    async def recordatorio_diario_rutas(self, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Función que se ejecuta todos los días a las 9:00 AM para mostrar rutas publicadas"""
        try:
            logger.info("🔔 Ejecutando recordatorio diario de rutas")
            
            # Obtener rutas publicadas activas para el grupo configurado
            if not GROUP_CHAT_ID:
                logger.warning("⚠️ GROUP_CHAT_ID no configurado")
                return
                
            rutas_publicadas = self.db.obtener_rutas_publicadas_activas(int(GROUP_CHAT_ID))
            
            if not rutas_publicadas:
                logger.info("📝 No hay rutas publicadas para mostrar en el recordatorio")
                return
            
            # Crear mensaje de recordatorio
            mensaje = "🌅 <b>¡Buenos días! Recordatorio de rutas publicadas</b> 🏍️\n\n"
            mensaje += f"📋 <b>Hay {len(rutas_publicadas)} ruta(s) publicada(s):</b>\n\n"
            
            for i, publicacion in enumerate(rutas_publicadas, 1):
                ruta = self.db.obtener_ruta(publicacion['ruta_id'])
                if not ruta:
                    continue
                
                mensaje += f"<b>{i}. {publicacion['nombre']}</b>\n"
                
                if publicacion.get('dia_ruta'):
                    mensaje += f"📅 <b>Fecha:</b> {publicacion['dia_ruta']}\n"
                if publicacion.get('hora_ruta'):
                    mensaje += f"⏰ <b>Hora:</b> {publicacion['hora_ruta']}\n"
                
                # Contar asistentes
                cantidad_asistentes = self.db.contar_asistentes(publicacion['id'])
                mensaje += f"👥 <b>Asistentes:</b> {cantidad_asistentes}\n\n"
            
            mensaje += "💡 <i>Usa /publicadas para ver más detalles y apuntarte a las rutas</i>"
            
            # Enviar mensaje al grupo
            if GROUP_CHAT_ID:
                await context.bot.send_message(
                    chat_id=GROUP_CHAT_ID,
                    text=mensaje,
                    parse_mode='HTML',
                    disable_web_page_preview=True
                )
                logger.info(f"✅ Recordatorio enviado al grupo {GROUP_CHAT_ID}")
            else:
                logger.warning("⚠️ No se pudo enviar recordatorio: GROUP_CHAT_ID no configurado")
                
        except Exception as e:
            logger.error(f"❌ Error en recordatorio diario: {e}")

    async def limpiar_rutas_vencidas(self, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Función que se ejecuta diariamente a las 00:01 para limpiar rutas vencidas"""
        try:
            logger.info("🧹 Ejecutando limpieza automática de rutas vencidas")
            
            # Obtener todas las rutas publicadas activas para el grupo configurado
            if not GROUP_CHAT_ID:
                logger.warning("⚠️ GROUP_CHAT_ID no configurado")
                return
                
            rutas_publicadas = self.db.obtener_rutas_publicadas_activas(int(GROUP_CHAT_ID))
            
            if not rutas_publicadas:
                logger.info("📝 No hay rutas publicadas para revisar")
                return
            
            fecha_hoy = date.today()
            rutas_eliminadas = 0
            
            for publicacion in rutas_publicadas:
                try:
                    # Verificar si la ruta tiene fecha configurada
                    if not publicacion.get('dia_ruta'):
                        continue
                    
                    # Parsear la fecha de la ruta (formato esperado: DD/MM/YYYY)
                    fecha_ruta_str = publicacion['dia_ruta']
                    
                    # Intentar varios formatos de fecha
                    fecha_ruta = None
                    formatos_fecha = ['%d/%m/%Y', '%Y-%m-%d', '%d-%m-%Y']
                    
                    for formato in formatos_fecha:
                        try:
                            fecha_ruta = datetime.strptime(fecha_ruta_str, formato).date()
                            break
                        except ValueError:
                            continue
                    
                    if not fecha_ruta:
                        logger.warning(f"⚠️ No se pudo parsear la fecha de la ruta {publicacion['id']}: {fecha_ruta_str}")
                        continue
                    
                    # Si la fecha de la ruta es anterior a hoy, eliminarla
                    if fecha_ruta < fecha_hoy:
                        logger.info(f"🗑️ Eliminando ruta vencida: {publicacion['nombre']} (fecha: {fecha_ruta_str})")
                        
                        # Desactivar la ruta publicada
                        self.db.desactivar_ruta_publicada(publicacion['id'])
                        
                        # También eliminar todos los asistentes de esta publicación
                        self.db.limpiar_asistentes_publicacion(publicacion['id'])
                        
                        rutas_eliminadas += 1
                        
                except Exception as e:
                    logger.error(f"❌ Error procesando ruta {publicacion.get('id', 'desconocida')}: {e}")
                    continue
            
            if rutas_eliminadas > 0:
                logger.info(f"✅ Limpieza completada: {rutas_eliminadas} ruta(s) vencida(s) eliminada(s)")
                
                # Opcional: Enviar notificación al grupo sobre la limpieza
                if GROUP_CHAT_ID and rutas_eliminadas > 0:
                    mensaje = f"🧹 <b>Limpieza automática completada</b>\n\n"
                    mensaje += f"Se han eliminado <b>{rutas_eliminadas}</b> ruta(s) vencida(s) del sistema.\n"
                    mensaje += f"<i>Esta limpieza se ejecuta automáticamente todos los días a las 00:01</i>"
                    
                    await context.bot.send_message(
                        chat_id=GROUP_CHAT_ID,
                        text=mensaje,
                        parse_mode='HTML',
                        disable_web_page_preview=True
                    )
            else:
                logger.info("✅ Limpieza completada: No había rutas vencidas para eliminar")
                
        except Exception as e:
            logger.error(f"❌ Error en limpieza automática de rutas vencidas: {e}")

    async def recordatorio_manual(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando manual para probar el recordatorio (solo administradores)"""
        if not self.can_use_bot(update):
            await update.message.reply_text("❌ Este comando solo funciona en el grupo configurado.")
            return
        
        user_id = update.effective_user.id
        # if not self.is_admin(user_id):
        #     await update.message.reply_text("❌ Solo los administradores pueden usar este comando.")
        #     return
        
        await update.message.reply_text("🔔 Enviando recordatorio manual...")
        await self.recordatorio_diario_rutas(context)

    async def limpiar_vencidas_manual(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Comando manual para probar la limpieza de rutas vencidas (solo administradores)"""
        if not self.can_use_bot(update):
            await update.message.reply_text("❌ Este comando solo funciona en el grupo configurado.")
            return
        
        user_id = update.effective_user.id
        # if not self.is_admin(user_id):
        #     await update.message.reply_text("❌ Solo los administradores pueden usar este comando.")
        #     return
        
        await update.message.reply_text("🧹 Ejecutando limpieza manual de rutas vencidas...")
        await self.limpiar_rutas_vencidas(context)

    def run(self):
        """Inicia el bot"""
        # Verificar configuración
        if TELEGRAM_TOKEN == "TU_TOKEN_AQUI":
            logger.error("❌ ERROR: Debes configurar TELEGRAM_TOKEN en el archivo .env")
            print("❌ ERROR: Debes configurar TELEGRAM_TOKEN en el archivo .env")
            return
        
        logger.info("🤖 Iniciando Bot de Rutas Moteras...")
        print("🤖 Iniciando Bot de Rutas Moteras...")
        
        if GROUP_CHAT_ID:
            logger.info(f"📢 Configurado para grupo: {GROUP_CHAT_ID}")
            print(f"📢 Configurado para grupo: {GROUP_CHAT_ID}")
        else:
            logger.warning("⚠️ No hay GROUP_CHAT_ID configurado - funcionará en cualquier chat")
            print("⚠️ No hay GROUP_CHAT_ID configurado - funcionará en cualquier chat")
        
        # Crear aplicación
        application = Application.builder().token(TELEGRAM_TOKEN).build()
        
        # Configurar job queue para recordatorios diarios
        job_queue = application.job_queue
        
        # Programar recordatorio diario a las 9:00 AM
        job_queue.run_daily(
            self.recordatorio_diario_rutas,
            time=time(hour=9, minute=0),  # 9:00 AM
            days=(0, 1, 2, 3, 4, 5, 6),  # Todos los días de la semana
            name="recordatorio_rutas_diario"
        )
        logger.info("📅 Recordatorio diario configurado para las 9:00 AM")
        print("📅 Recordatorio diario configurado para las 9:00 AM")
        
        # Programar limpieza automática de rutas vencidas a las 00:01
        job_queue.run_daily(
            self.limpiar_rutas_vencidas,
            time=time(hour=0, minute=1),  # 00:01 AM (medianoche)
            days=(0, 1, 2, 3, 4, 5, 6),  # Todos los días de la semana
            name="limpieza_rutas_vencidas"
        )
        logger.info("🧹 Limpieza automática configurada para las 00:01 AM")
        print("🧹 Limpieza automática configurada para las 00:01 AM")
        
        # Registrar handlers de comandos
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("ayuda", self.ayuda))
        application.add_handler(CommandHandler("help", self.ayuda))
        application.add_handler(CommandHandler("rutas", self.mostrar_rutas))
        application.add_handler(CommandHandler("rutas_del_dia", self.rutas_del_dia))
        application.add_handler(CommandHandler("publicadas", self.publicadas))
        application.add_handler(CommandHandler("recordatorio", self.recordatorio_manual))
        application.add_handler(CommandHandler("limpiar_vencidas", self.limpiar_vencidas_manual))
        application.add_handler(CommandHandler("mi_id", self.mostrar_mi_id))  # Comando temporal para obtener ID
        application.add_handler(CommandHandler("info_chat", self.mostrar_info_chat))  # Comando temporal para obtener info del chat
        
        # Handlers para callbacks de botones
        # Handlers del menú principal
        application.add_handler(CallbackQueryHandler(
            self.menu_callback, 
            pattern="^menu_"
        ))
        
        # Handler para volver al menú
        application.add_handler(CallbackQueryHandler(
            self.volver_menu_callback, 
            pattern="^volver_menu"
        ))
        
        application.add_handler(CallbackQueryHandler(
            self.vista_ruta_callback, 
            pattern="^vista_ruta_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.confirmar_publicar_callback, 
            pattern="^confirmar_publicar_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.editar_encuentro_callback, 
            pattern="^editar_encuentro_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.editar_restaurante_callback, 
            pattern="^editar_restaurante_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.editar_fecha_callback, 
            pattern="^editar_fecha_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.editar_hora_callback, 
            pattern="^editar_hora_"
        ))
        
        # Handlers para cancelar ediciones
        application.add_handler(CallbackQueryHandler(
            self.cancelar_encuentro_callback, 
            pattern="^cancelar_encuentro_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.cancelar_restaurante_callback, 
            pattern="^cancelar_restaurante_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.cancelar_fecha_callback, 
            pattern="^cancelar_fecha_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.cancelar_hora_callback, 
            pattern="^cancelar_hora_"
        ))
        
        application.add_handler(CallbackQueryHandler(
            self.volver_rutas_callback, 
            pattern="^volver_rutas"
        ))
        application.add_handler(CallbackQueryHandler(
            self.cancelar_publicacion_callback, 
            pattern="^cancelar_publicacion"
        ))
        
        # Handlers para calendario y selector de hora
        application.add_handler(CallbackQueryHandler(
            self.calendario_callback, 
            pattern="^cal_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.hora_selector_callback, 
            pattern="^hora_select_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.fecha_manual_callback, 
            pattern="^fecha_manual_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.hora_manual_callback, 
            pattern="^hora_manual_"
        ))
        
        # Handlers para gestión de rutas publicadas
        application.add_handler(CallbackQueryHandler(
            self.borrar_publicada_callback, 
            pattern="^borrar_publicada_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.limpiar_todas_callback, 
            pattern="^limpiar_todas_publicadas"
        ))
        
        # Handlers para gestión de asistentes
        application.add_handler(CallbackQueryHandler(
            self.apuntar_callback, 
            pattern="^apuntar_"
        ))
        application.add_handler(CallbackQueryHandler(
            self.desapuntar_callback, 
            pattern="^desapuntar_"
        ))
        
        # Handlers para añadir rutas
        application.add_handler(CallbackQueryHandler(
            self._cancelar_anadir_ruta_callback, 
            pattern="^cancelar_anadir_ruta"
        ))
        application.add_handler(CallbackQueryHandler(
            self._confirmar_guardar_ruta, 
            pattern="^confirmar_guardar_ruta"
        ))
        application.add_handler(CallbackQueryHandler(
            self._saltar_campo_callback, 
            pattern="^saltar_"
        ))
        
        # Handler para mensajes de texto (edición de enlaces)
        application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND, 
            self.manejar_mensajes_texto
        ))
        
        logger.info("✅ Bot configurado y listo")
        print("✅ Bot configurado y listo")
        print("🔄 Presiona Ctrl+C para detener el bot")
        
        # Iniciar el bot
        application.run_polling(drop_pending_updates=True)

    async def _mostrar_rutas_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Versión callback de mostrar_rutas para menú de botones"""
        query = update.callback_query
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ La gestión de rutas solo está disponible en privado. Escribe al bot directamente.")
            return
        
        try:
            rutas = self.db.obtener_todas_rutas()
            
            if not rutas:
                mensaje = "❌ No hay rutas disponibles."
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(mensaje, reply_markup=reply_markup)
                return
            
            # Verificar límite diario
            hoy = date.today().isoformat()
            # Verificar límite en el grupo configurado, no en el chat actual
            rutas_hoy = self.db.obtener_rutas_del_dia(GROUP_CHAT_ID, hoy)
            
            if len(rutas_hoy) >= MAX_RUTAS_POR_DIA:
                mensaje = f"📊 <b>Límite alcanzado:</b> Ya se han publicado {MAX_RUTAS_POR_DIA} rutas hoy.\nUsa 'Rutas del Día' para ver las rutas activas."
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
                return
            
            # Crear botones para seleccionar rutas
            keyboard = []
            for ruta in rutas:
                ruta_id, nombre = ruta['id'], ruta['nombre']
                # Limitar el nombre si es muy largo
                nombre_corto = nombre[:40] + "..." if len(nombre) > 40 else nombre
                keyboard.append([InlineKeyboardButton(f"🏍️ {nombre_corto}", callback_data=f"vista_ruta_{ruta_id}")])
            
            # Añadir botón de volver al menú
            keyboard.append([InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            mensaje = f"""
<b>🏍️ RUTAS DISPONIBLES</b>

<b>📊 Publicadas hoy:</b> {len(rutas_hoy)}/{MAX_RUTAS_POR_DIA}

Selecciona una ruta para ver los detalles:
            """
            
            await query.edit_message_text(
                mensaje, 
                reply_markup=reply_markup,
                parse_mode=ParseMode.HTML
            )
            
        except Exception as e:
            logger.error(f"Error en _mostrar_rutas_callback: {e}")
            mensaje = "❌ Error al cargar las rutas."
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(mensaje, reply_markup=reply_markup)

    async def _rutas_del_dia_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Versión callback de rutas_del_dia para menú de botones"""
        query = update.callback_query
        
        try:
            hoy = date.today().isoformat()
            # Siempre buscar en el grupo configurado, no en el chat actual
            rutas_publicadas = self.db.obtener_rutas_del_dia(GROUP_CHAT_ID, hoy)
            
            if not rutas_publicadas:
                mensaje = "📅 <b>No hay rutas publicadas para hoy.</b>\n\n¡Usa el menú para explorar rutas disponibles!"
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
                return

            mensaje = f"📅 <b>RUTAS PARA HOY ({date.today().strftime('%d/%m/%Y')})</b>\n\n"
            
            for ruta_pub in rutas_publicadas:
                mensaje += f"🏍️ <b>{ruta_pub['nombre']}</b>\n"
                mensaje += f"� <b>Fecha:</b> {ruta_pub['dia_ruta']}\n"
                mensaje += f"⏰ <b>Hora:</b> {ruta_pub['hora_ruta']}\n"
                
                # Mostrar asistentes
                asistentes = self.db.obtener_asistentes(ruta_pub['publicacion_id'])
                mensaje += f"👥 <b>Asistentes:</b> {len(asistentes)}\n\n"

            # Botón para volver al menú
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                mensaje, 
                reply_markup=reply_markup,
                parse_mode=ParseMode.HTML
            )
            
        except Exception as e:
            logger.error(f"Error en _rutas_del_dia_callback: {e}")
            mensaje = "❌ Error al cargar las rutas del día."
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(mensaje, reply_markup=reply_markup)

    async def _publicadas_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Versión callback de publicadas para menú de botones"""
        query = update.callback_query
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ La gestión de rutas solo está disponible en privado. Escribe al bot directamente.")
            return
        
        try:
            # Siempre buscar en el grupo configurado, no en el chat actual
            rutas_publicadas = self.db.obtener_rutas_publicadas_activas(GROUP_CHAT_ID)
            
            if not rutas_publicadas:
                mensaje = "📋 <b>No hay rutas publicadas actualmente.</b>"
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
                return

            mensaje = "📋 <b>RUTAS PUBLICADAS</b>\n\n"
            keyboard = []
            
            for ruta_pub in rutas_publicadas:
                # Los datos ya vienen como diccionario de obtener_rutas_publicadas_activas
                mensaje += f"🏍️ <b>{ruta_pub['nombre']}</b>\n"
                mensaje += f"📅 {ruta_pub['dia_ruta']} a las {ruta_pub['hora_ruta']}\n"
                mensaje += f"🆔 ID: {ruta_pub['publicacion_id']}\n\n"
                
                # Botón para borrar esta ruta
                keyboard.append([InlineKeyboardButton(
                    f"🗑️ Borrar: {ruta_pub['nombre'][:30]}{'...' if len(ruta_pub['nombre']) > 30 else ''}", 
                    callback_data=f"borrar_publicada_{ruta_pub['publicacion_id']}"
                )])
            
            # Botones de gestión
            keyboard.append([InlineKeyboardButton("🧹 Limpiar Todas", callback_data="limpiar_todas_publicadas")])
            keyboard.append([InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                mensaje, 
                reply_markup=reply_markup,
                parse_mode=ParseMode.HTML
            )
            
        except Exception as e:
            logger.error(f"Error en _publicadas_callback: {e}")
            mensaje = "❌ Error al cargar las rutas publicadas."
            keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(mensaje, reply_markup=reply_markup)

    # ===========================
    # FUNCIONES PARA AÑADIR RUTAS
    # ===========================
    
    async def _iniciar_anadir_ruta_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Inicia el proceso para añadir una nueva ruta"""
        query = update.callback_query
        await query.answer()
        
        if not self.can_use_bot(update, only_private=True):
            await query.edit_message_text("❌ Añadir rutas solo está disponible en privado. Escribe al bot directamente.")
            return
        
        # Limpiar datos previos
        context.user_data.clear()
        context.user_data['anadir_ruta'] = {
            'paso': 'nombre',
            'datos': {}
        }
        
        mensaje = """
🆕 <b>AÑADIR NUEVA RUTA</b>

📋 <b>Información sobre los campos:</b>

🔴 <b>Campos OBLIGATORIOS:</b>
• Nombre de la ruta
• Enlace de Google Maps de la ruta
• Punto de encuentro

🟢 <b>Campos OPCIONALES:</b>
• Restaurante
• Fecha (por defecto: "Por definir")
• Hora (por defecto: "Por confirmar")

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔴 <b>PASO 1/6: Nombre de la ruta</b>

Por favor, envía el <b>nombre</b> de la nueva ruta:

💡 <i>Ejemplo: "Barcelona - Montserrat - Manresa"</i>
        """
        
        keyboard = [[InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_anadir_ruta_texto(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Procesa los mensajes de texto durante el proceso de añadir ruta"""
        if 'anadir_ruta' not in context.user_data:
            return
        
        paso_actual = context.user_data['anadir_ruta']['paso']
        texto = update.message.text.strip()
        
        if paso_actual == 'nombre':
            await self._procesar_nombre_ruta(update, context, texto)
        elif paso_actual == 'link_ruta':
            await self._procesar_link_ruta(update, context, texto)
        elif paso_actual == 'link_encuentro':
            await self._procesar_link_encuentro(update, context, texto)
        elif paso_actual == 'link_restaurante':
            await self._procesar_link_restaurante(update, context, texto)
        elif paso_actual == 'fecha':
            await self._procesar_fecha_ruta(update, context, texto)
        elif paso_actual == 'hora':
            await self._procesar_hora_ruta(update, context, texto)

    async def _procesar_nombre_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE, nombre: str) -> None:
        """Procesa el nombre de la ruta"""
        if not nombre:
            await update.message.reply_text("❌ El nombre no puede estar vacío. Por favor, envía el nombre de la ruta:")
            return
        
        context.user_data['anadir_ruta']['datos']['nombre'] = nombre
        context.user_data['anadir_ruta']['paso'] = 'link_ruta'
        
        mensaje = f"""
✅ <b>Nombre guardado:</b> {nombre}

🔴 <b>PASO 2/6: Enlace de la ruta</b>

Por favor, envía el <b>enlace de Google Maps</b> de la ruta completa:

💡 <i>Cómo obtenerlo:</i>
1. Abre Google Maps
2. Planifica la ruta completa
3. Toca "Compartir" → "Copiar enlace"
4. Pégalo aquí

📝 <i>Ejemplo: https://maps.app.goo.gl/ABC123</i>
        """
        
        keyboard = [[InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_link_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE, link: str) -> None:
        """Procesa el enlace de la ruta"""
        if not self._validar_google_maps_url(link):
            await update.message.reply_text(
                "❌ Por favor, envía un enlace válido de Google Maps.\n\n"
                "💡 Debe contener 'google.com/maps' o 'maps.app.goo.gl'"
            )
            return
        
        context.user_data['anadir_ruta']['datos']['link_ruta'] = link
        context.user_data['anadir_ruta']['paso'] = 'link_encuentro'
        
        mensaje = f"""
✅ <b>Enlace de ruta guardado</b>

🔴 <b>PASO 3/6: Punto de encuentro</b>

Por favor, envía el <b>enlace de Google Maps</b> del punto de encuentro:

💡 <i>Cómo obtenerlo:</i>
1. Busca el lugar de encuentro en Google Maps
2. Toca "Compartir" → "Copiar enlace"
3. Pégalo aquí

📝 <i>Ejemplo: Parking de un centro comercial, gasolinera, etc.</i>
        """
        
        keyboard = [[InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_link_encuentro(self, update: Update, context: ContextTypes.DEFAULT_TYPE, link: str) -> None:
        """Procesa el enlace del punto de encuentro"""
        if not self._validar_google_maps_url(link):
            await update.message.reply_text(
                "❌ Por favor, envía un enlace válido de Google Maps.\n\n"
                "💡 Debe contener 'google.com/maps' o 'maps.app.goo.gl'"
            )
            return
        
        context.user_data['anadir_ruta']['datos']['link_encuentro'] = link
        context.user_data['anadir_ruta']['paso'] = 'link_restaurante'
        
        mensaje = f"""
✅ <b>Punto de encuentro guardado</b>

🟢 <b>PASO 4/6: Restaurante (OPCIONAL)</b>

Envía el <b>enlace de Google Maps</b> del restaurante donde pararéis, o envía "saltar" para omitir:

💡 <i>Este campo es opcional</i>
        """
        
        keyboard = [
            [InlineKeyboardButton("⏭️ Saltar", callback_data="saltar_restaurante")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_link_restaurante(self, update: Update, context: ContextTypes.DEFAULT_TYPE, link: str) -> None:
        """Procesa el enlace del restaurante"""
        if link.lower() in ['saltar', 'skip', 'omitir', 'no']:
            await self._continuar_fecha(update, context)
            return
        
        if not self._validar_google_maps_url(link):
            await update.message.reply_text(
                "❌ Por favor, envía un enlace válido de Google Maps o 'saltar' para omitir.\n\n"
                "💡 Debe contener 'google.com/maps' o 'maps.app.goo.gl'"
            )
            return
        
        context.user_data['anadir_ruta']['datos']['link_restaurante'] = link
        await self._continuar_fecha(update, context)

    async def _continuar_fecha(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Continúa al paso de fecha"""
        context.user_data['anadir_ruta']['paso'] = 'fecha'
        
        mensaje = f"""
🟢 <b>PASO 5/6: Fecha (OPCIONAL)</b>

Envía la <b>fecha</b> para la ruta, o envía "saltar" para usar "Por definir":

💡 <i>Ejemplos:</i>
• 15/09/2024
• Sábado 15 de septiembre
• Este fin de semana
• Por definir
        """
        
        keyboard = [
            [InlineKeyboardButton("⏭️ Saltar", callback_data="saltar_fecha")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Determinar si viene de callback o mensaje directo
        if update.callback_query:
            await update.callback_query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
        elif hasattr(update, 'message') and update.message:
            await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_fecha_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE, fecha: str) -> None:
        """Procesa la fecha de la ruta"""
        if fecha.lower() in ['saltar', 'skip', 'omitir']:
            await self._continuar_hora(update, context)
            return
        
        context.user_data['anadir_ruta']['datos']['fecha'] = fecha
        await self._continuar_hora(update, context)

    async def _continuar_hora(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Continúa al paso de hora"""
        context.user_data['anadir_ruta']['paso'] = 'hora'
        
        mensaje = f"""
🟢 <b>PASO 6/6: Hora (OPCIONAL)</b>

Envía la <b>hora</b> para la ruta, o envía "saltar" para usar "Por confirmar":

💡 <i>Ejemplos:</i>
• 09:00
• 9:30 de la mañana
• Salida 8:30, encuentro 9:00
• Por confirmar
        """
        
        keyboard = [
            [InlineKeyboardButton("⏭️ Saltar", callback_data="saltar_hora")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Determinar si viene de callback o mensaje directo
        if update.callback_query:
            await update.callback_query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
        elif hasattr(update, 'message') and update.message:
            await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _procesar_hora_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE, hora: str) -> None:
        """Procesa la hora de la ruta"""
        if hora.lower() in ['saltar', 'skip', 'omitir']:
            await self._mostrar_resumen_ruta(update, context)
            return
        
        context.user_data['anadir_ruta']['datos']['hora'] = hora
        await self._mostrar_resumen_ruta(update, context)

    async def _mostrar_resumen_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Muestra el resumen de la ruta antes de guardar"""
        datos = context.user_data['anadir_ruta']['datos']
        
        from datetime import date
        
        # Valores por defecto si no están establecidos
        fecha = datos.get('fecha', date.today().strftime("%d/%m/%Y"))
        hora = datos.get('hora', '09:00')
        restaurante = datos.get('restaurante', 'No configurado')
        
        # Si hay link de restaurante, usarlo, sino usar el texto por defecto
        if 'link_restaurante' in datos and datos['link_restaurante']:
            restaurante_texto = f'<a href="{datos["link_restaurante"]}">Ver ubicación</a>'
        else:
            restaurante_texto = restaurante
        
        mensaje = f"""
📋 <b>RESUMEN DE LA NUEVA RUTA</b>

🏍️ <b>Nombre:</b> {datos['nombre']}

🗺️ <b>Ruta:</b> <a href="{datos['link_ruta']}">Ver en Google Maps</a>

📍 <b>Encuentro:</b> <a href="{datos['link_encuentro']}">Ver ubicación</a>

🍽️ <b>Restaurante:</b> {restaurante_texto}

📅 <b>Fecha:</b> {fecha}

⏰ <b>Hora:</b> {hora}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

¿Confirmas que quieres <b>guardar esta ruta</b>?
        """
        
        keyboard = [
            [InlineKeyboardButton("✅ Guardar Ruta", callback_data="confirmar_guardar_ruta")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_anadir_ruta")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Determinar si viene de callback o mensaje directo
        if update.callback_query:
            await update.callback_query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup, disable_web_page_preview=True)
        elif hasattr(update, 'message') and update.message:
            await update.message.reply_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup, disable_web_page_preview=True)

    async def _confirmar_guardar_ruta(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Guarda la ruta en la base de datos"""
        query = update.callback_query
        await query.answer()
        
        datos = context.user_data['anadir_ruta']['datos']
        
        try:
            from datetime import date
            
            # Valores por defecto si no están establecidos
            fecha = datos.get('fecha', date.today().strftime("%d/%m/%Y"))
            hora = datos.get('hora', '09:00')
            restaurante = datos.get('link_restaurante', None)
            
            # Guardar en la base de datos
            ruta_id = self.db.agregar_ruta(
                nombre=datos['nombre'],
                link_ruta=datos['link_ruta'],
                link_encuentro=datos['link_encuentro'],
                link_restaurante=restaurante,
                fecha=fecha,
                hora=hora
            )
            
            if ruta_id:
                mensaje = f"""
✅ <b>¡RUTA AÑADIDA CORRECTAMENTE!</b>

🆔 <b>ID de la ruta:</b> {ruta_id}
🏍️ <b>Nombre:</b> {datos['nombre']}

🎉 La ruta ya está disponible para publicar en el bot.

💡 <i>Puedes encontrarla en "🏍️ Ver Rutas"</i>
                """
                
                keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)
                
                # Limpiar datos
                context.user_data.clear()
            else:
                await query.edit_message_text("❌ Error al guardar la ruta. Inténtalo de nuevo.")
                
        except Exception as e:
            logger.error(f"Error al guardar ruta: {e}")
            await query.edit_message_text("❌ Error inesperado al guardar la ruta.")

    async def _cancelar_anadir_ruta_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Cancela el proceso de añadir ruta"""
        query = update.callback_query
        await query.answer()
        
        # Limpiar datos
        context.user_data.clear()
        
        mensaje = "❌ <b>Proceso cancelado</b>\n\nNo se añadió ninguna ruta."
        keyboard = [[InlineKeyboardButton("🔙 Volver al Menú", callback_data="volver_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(mensaje, parse_mode=ParseMode.HTML, reply_markup=reply_markup)

    async def _saltar_campo_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja los callbacks de saltar campos opcionales"""
        query = update.callback_query
        callback_data = query.data
        await query.answer()
        
        from datetime import date
        
        if callback_data == "saltar_restaurante":
            # Establecer valor por defecto para restaurante
            context.user_data['anadir_ruta']['datos']['restaurante'] = "No configurado"
            await self._continuar_fecha(update, context)
        elif callback_data == "saltar_fecha":
            # Establecer fecha de hoy por defecto
            fecha_hoy = date.today().strftime("%d/%m/%Y")
            context.user_data['anadir_ruta']['datos']['fecha'] = fecha_hoy
            await self._continuar_hora(update, context)
        elif callback_data == "saltar_hora":
            # Establecer hora por defecto 09:00
            context.user_data['anadir_ruta']['datos']['hora'] = "09:00"
            await self._mostrar_resumen_ruta(update, context)

    def _validar_google_maps_url(self, url: str) -> bool:
        """Valida si la URL es de Google Maps"""
        if not url:
            return False
        return 'google.com/maps' in url or 'goo.gl' in url or 'maps.app.goo.gl' in url

def main():
    """Función principal para ejecutar el bot"""
    try:
        bot = TelegramBotGrupo()
        bot.run()
    except KeyboardInterrupt:
        print("\n🛑 Bot detenido por el usuario")
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        logger.error(f"Error inesperado: {e}")

if __name__ == "__main__":
    main()
