# Configuración para el Bot de Telegram
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Token del bot (obtenido de @BotFather)
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN', 'TU_TOKEN_AQUI')

# ID del grupo donde funcionará el bot (se configurará después de crear el grupo)
GROUP_CHAT_ID = os.getenv('GROUP_CHAT_ID', None)

# ID del tema/hilo donde se publicarán las rutas (opcional, para grupos con temas habilitados)
RUTAS_THREAD_ID = os.getenv('RUTAS_THREAD_ID', None)

# IDs de administradores que pueden gestionar el bot
ADMIN_USER_IDS = [
    '266060502',  # Cristian - Admin principal
]

# Configuración de la base de datos
DATABASE_NAME = 'rutas_moto.db'

# Configuración del bot
MAX_RUTAS_POR_DIA = 5  # Máximo de rutas que se pueden publicar por día

# Configuración de logging
LOG_LEVEL = 'INFO'
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# Mensajes del bot
MESSAGES = {
    'welcome': """
🏍️ ¡Bienvenido al Bot de Rutas de Moto! 🏍️

Comandos disponibles:
• /rutas - Ver todas las rutas disponibles
• /crear_ruta - Crear una nueva ruta
• /ayuda - Ver este mensaje de ayuda

¡Vamos a rodar! 🛣️
    """,
    
    'help': """
🏍️ **Comandos del Bot de Rutas de Moto** 🏍️

📋 **/rutas** - Muestra todas las rutas disponibles con botones para seleccionar

🆕 **/crear_ruta** - Inicia el proceso para crear una nueva ruta
   - Te pediré: nombre, link de la ruta, punto de encuentro y restaurante

✅ **Seleccionar ruta** - Después de usar /rutas, puedes:
   - Hacer clic en una ruta para publicarla
   - Los usuarios pueden reaccionar con 👍 para apuntarse
   - La lista de asistentes se actualiza automáticamente

🔄 **Reacciones**:
   - 👍 = Apuntarse a la ruta
   - 👎 = Desapuntarse de la ruta

ℹ️ **/ayuda** - Muestra este mensaje

¡Disfruta de las rutas! 🛣️🏍️
    """,
    
    'no_routes': "No hay rutas disponibles. Usa /crear_ruta para agregar una.",
    
    'route_created': """
🎉 **¡Ruta creada exitosamente!** 🎉

📋 **Detalles de la ruta:**
• **Nombre:** {nombre}
• **ID:** {ruta_id}

Usa /rutas para ver todas las rutas disponibles.
    """,
    
    'route_published': "✅ ¡Ruta publicada exitosamente!",
    
    'error_route_not_found': "❌ Error: No se pudo encontrar la publicación de la ruta."
}
