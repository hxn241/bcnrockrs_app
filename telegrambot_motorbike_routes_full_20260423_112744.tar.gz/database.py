import sqlite3
import os
from typing import List, Dict, Optional

class Database:
    def __init__(self, db_name: str = "rutas_moto.db"):
        self.db_name = db_name
        self.init_database()
    
    def init_database(self):
        """Inicializa la base de datos y crea las tablas necesarias"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            
            # Tabla de rutas
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS rutas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    link_ruta TEXT NOT NULL,
                    link_encuentro TEXT NOT NULL,
                    link_restaurante TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Tabla para almacenar publicaciones activas de rutas
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS rutas_publicadas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ruta_id INTEGER,
                    message_id INTEGER,
                    chat_id INTEGER,
                    dia_ruta TEXT,
                    hora_ruta TEXT,
                    link_encuentro_personalizado TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (ruta_id) REFERENCES rutas (id)
                )
            ''')
            
            # Añadir columna si no existe (para compatibilidad con bases de datos existentes)
            try:
                cursor.execute('ALTER TABLE rutas_publicadas ADD COLUMN link_encuentro_personalizado TEXT')
            except sqlite3.OperationalError:
                # La columna ya existe
                pass
            
            # Añadir campos de fecha y hora a la tabla rutas si no existen
            try:
                cursor.execute('ALTER TABLE rutas ADD COLUMN fecha TEXT DEFAULT "Por definir"')
            except sqlite3.OperationalError:
                # La columna ya existe
                pass
            
            try:
                cursor.execute('ALTER TABLE rutas ADD COLUMN hora TEXT DEFAULT "Por confirmar"')
            except sqlite3.OperationalError:
                # La columna ya existe
                pass
            
            # Tabla para asistentes
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS asistentes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    publicacion_id INTEGER,
                    user_id INTEGER,
                    username TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (publicacion_id) REFERENCES rutas_publicadas (id)
                )
            ''')
            
            conn.commit()
    
    def obtener_rutas_del_dia(self, chat_id: int, dia_ruta: str) -> List[Dict]:
        """Obtiene todas las rutas publicadas para un día específico"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT rp.*, r.nombre 
                FROM rutas_publicadas rp
                JOIN rutas r ON rp.ruta_id = r.id
                WHERE rp.chat_id = ? AND rp.dia_ruta = ? AND rp.is_active = 1
                ORDER BY rp.hora_ruta
            ''', (chat_id, dia_ruta))
            
            rutas = cursor.fetchall()
            return [{
                'publicacion_id': ruta[0],
                'ruta_id': ruta[1],
                'message_id': ruta[2],
                'chat_id': ruta[3],
                'dia_ruta': ruta[4],
                'hora_ruta': ruta[5],
                'link_encuentro_personalizado': ruta[6],
                'is_active': ruta[7],
                'created_at': ruta[8],
                'nombre': ruta[9]
            } for ruta in rutas]
    
    def agregar_ruta(self, nombre: str, link_ruta: str, link_encuentro: str, link_restaurante: str = None, fecha: str = "Por definir", hora: str = "Por confirmar") -> int:
        """Agrega una nueva ruta a la base de datos"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO rutas (nombre, link_ruta, link_encuentro, link_restaurante, fecha, hora)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (nombre, link_ruta, link_encuentro, link_restaurante, fecha, hora))
            conn.commit()
            return cursor.lastrowid
    
    def obtener_todas_rutas(self) -> List[Dict]:
        """Obtiene todas las rutas de la base de datos"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM rutas ORDER BY nombre')
            rutas = cursor.fetchall()
            
            return [{
                'id': ruta[0],
                'nombre': ruta[1],
                'link_ruta': ruta[2],
                'link_encuentro': ruta[3],
                'link_restaurante': ruta[4],
                'created_at': ruta[5],
                'fecha': ruta[6] if len(ruta) > 6 else 'Por definir',
                'hora': ruta[7] if len(ruta) > 7 else 'Por confirmar'
            } for ruta in rutas]
    
    def obtener_ruta(self, ruta_id: int) -> Optional[Dict]:
        """Obtiene una ruta específica por ID"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM rutas WHERE id = ?', (ruta_id,))
            ruta = cursor.fetchone()
            
            if ruta:
                return {
                    'id': ruta[0],
                    'nombre': ruta[1],
                    'link_ruta': ruta[2],
                    'link_encuentro': ruta[3],
                    'link_restaurante': ruta[4],
                    'created_at': ruta[5],
                    'fecha': ruta[6] if len(ruta) > 6 else 'Por definir',
                    'hora': ruta[7] if len(ruta) > 7 else 'Por confirmar'
                }
            return None
    
    def contar_rutas_por_dia(self, chat_id: int, dia_ruta: str) -> int:
        """Cuenta cuántas rutas están publicadas para un día específico en un chat"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM rutas_publicadas 
                WHERE chat_id = ? AND dia_ruta = ? AND is_active = 1
            ''', (chat_id, dia_ruta))
            return cursor.fetchone()[0]
    
    def publicar_ruta(self, ruta_id: int, message_id: int, chat_id: int, dia_ruta: str, hora_ruta: str, 
                     link_encuentro_personalizado: str = None, limite_por_dia: int = 5) -> tuple:
        """
        Registra una publicación de ruta
        Retorna (publicacion_id, success, mensaje_error)
        """
        # Verificar límite de rutas por día
        rutas_existentes = self.contar_rutas_por_dia(chat_id, dia_ruta)
        
        if rutas_existentes >= limite_por_dia:
            return (None, False, f"❌ Límite alcanzado: Ya hay {rutas_existentes} rutas publicadas para {dia_ruta}. Máximo permitido: {limite_por_dia}")
        
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO rutas_publicadas (ruta_id, message_id, chat_id, dia_ruta, hora_ruta, link_encuentro_personalizado)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (ruta_id, message_id, chat_id, dia_ruta, hora_ruta, link_encuentro_personalizado))
            conn.commit()
            return (cursor.lastrowid, True, None)
    
    def agregar_asistente(self, publicacion_id: int, user_id: int, username: str):
        """Agrega un asistente a una ruta publicada"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            # Verificar si ya existe el asistente
            cursor.execute('''
                SELECT id FROM asistentes 
                WHERE publicacion_id = ? AND user_id = ?
            ''', (publicacion_id, user_id))
            
            if not cursor.fetchone():
                cursor.execute('''
                    INSERT INTO asistentes (publicacion_id, user_id, username)
                    VALUES (?, ?, ?)
                ''', (publicacion_id, user_id, username))
                conn.commit()
    
    def quitar_asistente(self, publicacion_id: int, user_id: int):
        """Quita un asistente de una ruta publicada"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                DELETE FROM asistentes 
                WHERE publicacion_id = ? AND user_id = ?
            ''', (publicacion_id, user_id))
            conn.commit()
    
    def obtener_asistentes(self, publicacion_id: int) -> List[str]:
        """Obtiene la lista de asistentes de una ruta publicada"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT username FROM asistentes 
                WHERE publicacion_id = ?
                ORDER BY created_at
            ''', (publicacion_id,))
            asistentes = cursor.fetchall()
            return [asistente[0] for asistente in asistentes]
    
    def obtener_publicacion_por_mensaje(self, message_id: int, chat_id: int) -> Optional[Dict]:
        """Obtiene información de una publicación por message_id y chat_id"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT rp.*, r.nombre, r.link_ruta, r.link_encuentro, r.link_restaurante
                FROM rutas_publicadas rp
                JOIN rutas r ON rp.ruta_id = r.id
                WHERE rp.message_id = ? AND rp.chat_id = ? AND rp.is_active = 1
            ''', (message_id, chat_id))
            
            result = cursor.fetchone()
            if result:
                return {
                    'publicacion_id': result[0],
                    'ruta_id': result[1],
                    'message_id': result[2],
                    'chat_id': result[3],
                    'dia_ruta': result[4],
                    'hora_ruta': result[5],
                    'link_encuentro_personalizado': result[6],
                    'is_active': result[7],
                    'created_at': result[8],
                    'nombre': result[9],
                    'link_ruta': result[10],
                    'link_encuentro': result[11],
                    'link_restaurante': result[12]
                }
            return None
    
    def eliminar_ruta(self, ruta_id: int) -> bool:
        """Elimina una ruta de la base de datos"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM rutas WHERE id = ?', (ruta_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    def obtener_link_encuentro_efectivo(self, ruta_data) -> str:
        """
        Obtiene el link de encuentro efectivo para una publicación o ruta
        Si recibe un ID de ruta, obtiene el link por defecto de la ruta
        Si recibe un dict con publicación, usa el personalizado o el por defecto
        """
        if isinstance(ruta_data, int):
            # Es un ID de ruta, obtener el link por defecto
            ruta = self.obtener_ruta(ruta_data)
            return ruta['link_encuentro'] if ruta else ""
        elif isinstance(ruta_data, dict):
            # Es info de publicación
            if ruta_data.get('link_encuentro_personalizado'):
                return ruta_data['link_encuentro_personalizado']
            else:
                return ruta_data['link_encuentro']
        else:
            return ""
    
    def obtener_historial_completo(self) -> List[Dict]:
        """Obtiene el historial completo de rutas publicadas con asistentes"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    r.nombre,
                    rp.dia_ruta,
                    rp.hora_ruta,
                    rp.created_at as fecha_publicacion,
                    GROUP_CONCAT(a.username, ', ') as asistentes,
                    COUNT(a.id) as total_asistentes
                FROM rutas_publicadas rp
                JOIN rutas r ON rp.ruta_id = r.id
                LEFT JOIN asistentes a ON rp.id = a.publicacion_id
                GROUP BY rp.id, r.nombre, rp.dia_ruta, rp.hora_ruta, rp.created_at
                ORDER BY rp.created_at DESC
            ''')
            
            resultados = cursor.fetchall()
            
            return [{
                'nombre_ruta': resultado[0],
                'dia_ruta': resultado[1],
                'hora_ruta': resultado[2],
                'fecha_publicacion': resultado[3],
                'asistentes': resultado[4] if resultado[4] else 'Ninguno',
                'total_asistentes': resultado[5]
            } for resultado in resultados]
    
    def obtener_asistencias_usuario(self, username: str) -> List[Dict]:
        """Obtiene todas las rutas a las que ha asistido un usuario"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    r.nombre,
                    rp.dia_ruta,
                    rp.hora_ruta,
                    a.created_at as fecha_apuntado
                FROM asistentes a
                JOIN rutas_publicadas rp ON a.publicacion_id = rp.id
                JOIN rutas r ON rp.ruta_id = r.id
                WHERE a.username = ?
                ORDER BY rp.created_at DESC
            ''', (username,))
            
            resultados = cursor.fetchall()
            
            return [{
                'nombre_ruta': resultado[0],
                'dia_ruta': resultado[1],
                'hora_ruta': resultado[2],
                'fecha_apuntado': resultado[3]
            } for resultado in resultados]

    def actualizar_punto_encuentro_personalizado(self, ruta_id: int, nuevo_enlace: str) -> bool:
        """Actualiza el punto de encuentro personalizado para una ruta específica"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE rutas 
                    SET link_encuentro = ? 
                    WHERE id = ?
                ''', (nuevo_enlace, ruta_id))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error actualizando punto de encuentro: {e}")
            return False

    def actualizar_restaurante_personalizado(self, ruta_id: int, nuevo_enlace: str) -> bool:
        """Actualiza el restaurante personalizado para una ruta específica"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE rutas 
                    SET link_restaurante = ? 
                    WHERE id = ?
                ''', (nuevo_enlace, ruta_id))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error actualizando restaurante: {e}")
            return False

    def actualizar_fecha_ruta(self, ruta_id: int, nueva_fecha: str) -> bool:
        """Actualiza la fecha para una ruta específica"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE rutas 
                    SET fecha = ? 
                    WHERE id = ?
                ''', (nueva_fecha, ruta_id))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error actualizando fecha: {e}")
            return False

    def actualizar_hora_ruta(self, ruta_id: int, nueva_hora: str) -> bool:
        """Actualiza la hora para una ruta específica"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE rutas 
                    SET hora = ? 
                    WHERE id = ?
                ''', (nueva_hora, ruta_id))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error actualizando hora: {e}")
            return False

    def obtener_rutas_publicadas_activas(self, chat_id: int) -> List[Dict]:
        """Obtiene todas las rutas publicadas activas para un chat"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT rp.*, r.nombre 
                    FROM rutas_publicadas rp
                    JOIN rutas r ON rp.ruta_id = r.id
                    WHERE rp.chat_id = ? AND rp.is_active = 1
                    ORDER BY rp.created_at DESC
                ''', (chat_id,))
                
                rutas = cursor.fetchall()
                return [{
                    'publicacion_id': ruta[0],
                    'ruta_id': ruta[1],
                    'message_id': ruta[2],
                    'chat_id': ruta[3],
                    'dia_ruta': ruta[4],
                    'hora_ruta': ruta[5],
                    'link_encuentro_personalizado': ruta[6],
                    'is_active': ruta[7],
                    'created_at': ruta[8],
                    'nombre': ruta[9]
                } for ruta in rutas]
        except Exception as e:
            print(f"Error obteniendo rutas publicadas: {e}")
            return []

    def desactivar_ruta_publicada(self, publicacion_id: int) -> bool:
        """Desactiva una ruta publicada y elimina sus asistentes (para rutas canceladas)"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                
                # Primero eliminar todos los asistentes de esta publicación
                cursor.execute('''
                    DELETE FROM asistentes 
                    WHERE publicacion_id = ?
                ''', (publicacion_id,))
                
                asistentes_eliminados = cursor.rowcount
                
                # Luego desactivar la ruta publicada
                cursor.execute('''
                    UPDATE rutas_publicadas 
                    SET is_active = 0 
                    WHERE id = ?
                ''', (publicacion_id,))
                
                ruta_desactivada = cursor.rowcount > 0
                
                if ruta_desactivada and asistentes_eliminados > 0:
                    print(f"✅ Ruta desactivada y {asistentes_eliminados} asistente(s) eliminados")
                elif ruta_desactivada:
                    print(f"✅ Ruta desactivada (sin asistentes)")
                
                return ruta_desactivada
        except Exception as e:
            print(f"Error desactivando ruta publicada: {e}")
            return False

    def limpiar_todas_rutas_publicadas(self, chat_id: int) -> int:
        """Desactiva todas las rutas publicadas de un chat y elimina todos sus asistentes"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                
                # Primero, eliminar todos los asistentes de las rutas activas de este chat
                cursor.execute('''
                    DELETE FROM asistentes 
                    WHERE publicacion_id IN (
                        SELECT id FROM rutas_publicadas 
                        WHERE chat_id = ? AND is_active = 1
                    )
                ''', (chat_id,))
                
                asistentes_eliminados = cursor.rowcount
                
                # Luego, desactivar todas las rutas publicadas
                cursor.execute('''
                    UPDATE rutas_publicadas 
                    SET is_active = 0 
                    WHERE chat_id = ? AND is_active = 1
                ''', (chat_id,))
                
                rutas_desactivadas = cursor.rowcount
                
                if rutas_desactivadas > 0:
                    print(f"✅ {rutas_desactivadas} ruta(s) desactivada(s) y {asistentes_eliminados} asistente(s) eliminados")
                
                return rutas_desactivadas
        except Exception as e:
            print(f"Error limpiando rutas publicadas: {e}")
            return 0

    def agregar_asistente(self, publicacion_id: int, user_id: int, username: str = None) -> bool:
        """Añade un asistente a una ruta publicada"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                
                # Verificar si ya está apuntado
                cursor.execute('''
                    SELECT id FROM asistentes 
                    WHERE publicacion_id = ? AND user_id = ?
                ''', (publicacion_id, user_id))
                
                if cursor.fetchone():
                    return False  # Ya está apuntado
                
                # Añadir asistente
                cursor.execute('''
                    INSERT INTO asistentes (publicacion_id, user_id, username)
                    VALUES (?, ?, ?)
                ''', (publicacion_id, user_id, username))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error añadiendo asistente: {e}")
            return False

    def quitar_asistente(self, publicacion_id: int, user_id: int) -> bool:
        """Quita un asistente de una ruta publicada"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    DELETE FROM asistentes 
                    WHERE publicacion_id = ? AND user_id = ?
                ''', (publicacion_id, user_id))
                
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error quitando asistente: {e}")
            return False

    def obtener_asistentes(self, publicacion_id: int) -> List[Dict]:
        """Obtiene la lista de asistentes de una ruta publicada"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT user_id, username, created_at
                    FROM asistentes 
                    WHERE publicacion_id = ?
                    ORDER BY created_at ASC
                ''', (publicacion_id,))
                
                columns = [description[0] for description in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as e:
            print(f"Error obteniendo asistentes: {e}")
            return []

    def contar_asistentes(self, publicacion_id: int) -> int:
        """Cuenta el número de asistentes de una ruta publicada"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT COUNT(*) FROM asistentes 
                    WHERE publicacion_id = ?
                ''', (publicacion_id,))
                
                return cursor.fetchone()[0]
        except Exception as e:
            print(f"Error contando asistentes: {e}")
            return 0

    def obtener_publicacion_por_mensaje(self, chat_id: int, message_id: int) -> Optional[Dict]:
        """Obtiene una publicación por su chat_id y message_id"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT rp.*, r.nombre, r.link_ruta, r.link_encuentro, r.link_restaurante, r.fecha, r.hora
                    FROM rutas_publicadas rp
                    JOIN rutas r ON rp.ruta_id = r.id
                    WHERE rp.chat_id = ? AND rp.message_id = ? AND rp.is_active = 1
                ''', (chat_id, message_id))
                
                row = cursor.fetchone()
                if row:
                    columns = [description[0] for description in cursor.description]
                    return dict(zip(columns, row))
                return None
        except Exception as e:
            print(f"Error obteniendo publicación por mensaje: {e}")
            return None

    def limpiar_asistentes_publicacion(self, publicacion_id: int) -> bool:
        """Elimina todos los asistentes de una publicación específica"""
        try:
            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    DELETE FROM asistentes 
                    WHERE publicacion_id = ?
                ''', (publicacion_id,))
                conn.commit()
                
                cantidad_eliminados = cursor.rowcount
                if cantidad_eliminados > 0:
                    print(f"✅ Eliminados {cantidad_eliminados} asistente(s) de la publicación {publicacion_id}")
                
                return True
        except Exception as e:
            print(f"Error limpiando asistentes de publicación {publicacion_id}: {e}")
            return False
