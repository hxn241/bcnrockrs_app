#!/usr/bin/env python3
"""
Script para limpiar todas las rutas publicadas de la base de datos
"""

from database import Database

def limpiar_rutas_publicadas():
    """Elimina todas las rutas publicadas de la base de datos"""
    db = Database()
    
    try:
        # Obtener todas las rutas publicadas antes de borrar
        import sqlite3
        with sqlite3.connect(db.db_name) as conn:
            cursor = conn.cursor()
            
            # Contar rutas publicadas antes
            cursor.execute('SELECT COUNT(*) FROM rutas_publicadas WHERE is_active = 1')
            count_antes = cursor.fetchone()[0]
            
            print(f"📊 Rutas publicadas activas encontradas: {count_antes}")
            
            if count_antes > 0:
                # Marcar todas como inactivas (borrado lógico)
                cursor.execute('UPDATE rutas_publicadas SET is_active = 0')
                
                # O borrar físicamente (descomenta si prefieres borrado físico)
                # cursor.execute('DELETE FROM rutas_publicadas')
                
                conn.commit()
                print(f"✅ {count_antes} rutas publicadas han sido marcadas como inactivas")
                print("🔄 El límite diario se ha reseteado")
            else:
                print("ℹ️ No hay rutas publicadas activas para limpiar")
                
    except Exception as e:
        print(f"❌ Error limpiando rutas publicadas: {e}")

if __name__ == "__main__":
    print("🧹 Limpiando rutas publicadas...")
    limpiar_rutas_publicadas()
    print("✨ Proceso completado")
