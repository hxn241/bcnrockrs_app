#!/bin/bash
# Script para iniciar el bot de rutas moteras

echo "🤖 INICIANDO BOT DE RUTAS MOTERAS"
echo "================================="

# Cambiar al directorio del proyecto
cd /home/cristian/projects/telegrambot_motorbike_routes

# Verificar configuración
if [[ ! -f ".env" ]]; then
    echo "❌ Error: Archivo .env no encontrado"
    exit 1
fi

# Verificar token
TOKEN=$(grep "TELEGRAM_TOKEN=" .env | cut -d'=' -f2)
if [[ -z "$TOKEN" ]] || [[ "$TOKEN" == "TU_TOKEN_AQUI" ]]; then
    echo "❌ Error: Token no configurado en .env"
    exit 1
fi

# Verificar grupo
GROUP_ID=$(grep "GROUP_CHAT_ID=" .env | cut -d'=' -f2)
if [[ -z "$GROUP_ID" ]]; then
    echo "❌ Error: GROUP_CHAT_ID no configurado en .env"
    exit 1
fi

echo "✅ Configuración verificada"
echo "📢 Grupo: $GROUP_ID"
echo "🚀 Iniciando bot..."
echo ""

# Ejecutar bot con uv
uv run python bot_grupo.py
