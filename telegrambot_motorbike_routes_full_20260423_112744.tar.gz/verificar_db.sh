#!/bin/bash
# Script para verificar el estado de la base de datos

echo "📊 ESTADO DE LA BASE DE DATOS"
echo "============================="

cd /home/cristian/projects/telegrambot_motorbike_routes
source /home/cristian/projects/.venv/bin/activate

python3 -c "
import sqlite3
import os
from database import Database

if os.path.exists('rutas_moto.db'):
    print('✅ Base de datos encontrada')
    
    # Usar la clase Database
    db = Database()
    
    # Estadísticas generales
    conn = sqlite3.connect('rutas_moto.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM rutas')
    total_rutas = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM rutas_publicadas')
    rutas_publicadas = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM asistentes')
    total_asistentes = cursor.fetchone()[0]
    
    print(f'🏍️  Total rutas: {total_rutas}')
    print(f'📅 Rutas publicadas: {rutas_publicadas}')
    print(f'👥 Total asistentes: {total_asistentes}')
    
    # Rutas más populares
    cursor.execute('''
        SELECT r.nombre, COUNT(a.id) as asistentes
        FROM rutas r
        LEFT JOIN rutas_publicadas rp ON r.id = rp.ruta_id
        LEFT JOIN asistentes a ON rp.id = a.publicacion_id
        GROUP BY r.id, r.nombre
        ORDER BY asistentes DESC
        LIMIT 5
    ''')
    populares = cursor.fetchall()
    
    if populares:
        print('')
        print('📈 Rutas más populares:')
        for i, (nombre, count) in enumerate(populares, 1):
            print(f'  {i}. {nombre} ({count} asistentes)')
    
    conn.close()
else:
    print('❌ Base de datos no encontrada')
"
