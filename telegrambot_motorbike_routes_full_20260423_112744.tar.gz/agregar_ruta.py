#!/usr/bin/env python3
"""
Script para agregar nuevas rutas a la base de datos del bot de rutas moteras.
"""

import sqlite3
import os
import sys
from database import Database
from colorama import init, Fore, Style

# Inicializar colorama para colores en terminal
init(autoreset=True)

def print_header():
    """Imprime el header del script"""
    print(f"{Fore.CYAN}{'='*60}")
    print(f"{Fore.CYAN}🏍️  AGREGAR NUEVA RUTA MOTERA 🏍️")
    print(f"{Fore.CYAN}{'='*60}")
    print()

def print_field_info():
    """Imprime información sobre los campos"""
    print(f"{Fore.YELLOW}📋 INFORMACIÓN DE CAMPOS:")
    print(f"{Fore.RED}🔴 Campos OBLIGATORIOS:")
    print(f"   • Nombre de la ruta")
    print(f"   • Enlace de Google Maps de la ruta")
    print(f"   • Punto de encuentro")
    print()
    print(f"{Fore.GREEN}🟢 Campos OPCIONALES:")
    print(f"   • Restaurante")
    print(f"   • Fecha (por defecto: 'Por definir')")
    print(f"   • Hora (por defecto: 'Por confirmar')")
    print()

def validate_google_maps_url(url: str) -> bool:
    """Valida si la URL es de Google Maps"""
    if not url:
        return False
    return 'google.com/maps' in url or 'goo.gl' in url or 'maps.app.goo.gl' in url

def get_input(prompt: str, required: bool = False, validate_url: bool = False) -> str:
    """Obtiene input del usuario con validación"""
    while True:
        color = Fore.RED if required else Fore.GREEN
        required_text = " (OBLIGATORIO)" if required else " (Opcional)"
        
        value = input(f"{color}{prompt}{required_text}: {Style.RESET_ALL}").strip()
        
        # Si es requerido y está vacío
        if required and not value:
            print(f"{Fore.RED}❌ Este campo es obligatorio. Por favor, ingresa un valor.")
            continue
        
        # Si no es requerido y está vacío, devolver vacío
        if not required and not value:
            return ""
        
        # Validar URL si es necesario
        if validate_url and value and not validate_google_maps_url(value):
            print(f"{Fore.RED}❌ Por favor, ingresa una URL válida de Google Maps.")
            print(f"{Fore.YELLOW}💡 Ejemplo: https://maps.app.goo.gl/ejemplo")
            continue
        
        return value

def mostrar_resumen(datos: dict):
    """Muestra un resumen de los datos ingresados"""
    print(f"\n{Fore.CYAN}📋 RESUMEN DE LA NUEVA RUTA:")
    print(f"{Fore.CYAN}{'='*40}")
    
    print(f"{Fore.WHITE}🏍️  Nombre: {Fore.YELLOW}{datos['nombre']}")
    print(f"{Fore.WHITE}🗺️  Ruta: {Fore.BLUE}{datos['link_ruta']}")
    print(f"{Fore.WHITE}📍 Encuentro: {Fore.BLUE}{datos['link_encuentro']}")
    
    if datos['link_restaurante']:
        print(f"{Fore.WHITE}🍽️  Restaurante: {Fore.BLUE}{datos['link_restaurante']}")
    else:
        print(f"{Fore.WHITE}🍽️  Restaurante: {Fore.LIGHTBLACK_EX}(No especificado)")
    
    if datos['fecha']:
        print(f"{Fore.WHITE}📅 Fecha: {Fore.GREEN}{datos['fecha']}")
    else:
        print(f"{Fore.WHITE}📅 Fecha: {Fore.LIGHTBLACK_EX}Por definir")
    
    if datos['hora']:
        print(f"{Fore.WHITE}⏰ Hora: {Fore.GREEN}{datos['hora']}")
    else:
        print(f"{Fore.WHITE}⏰ Hora: {Fore.LIGHTBLACK_EX}Por confirmar")

def confirmar_guardado() -> bool:
    """Confirma si el usuario quiere guardar la ruta"""
    while True:
        respuesta = input(f"\n{Fore.YELLOW}¿Guardar esta ruta? (s/n): {Style.RESET_ALL}").strip().lower()
        if respuesta in ['s', 'si', 'sí', 'y', 'yes']:
            return True
        elif respuesta in ['n', 'no']:
            return False
        else:
            print(f"{Fore.RED}❌ Por favor responde 's' para sí o 'n' para no.")

def main():
    """Función principal"""
    print_header()
    print_field_info()
    
    try:
        # Verificar que existe la base de datos
        if not os.path.exists('rutas_moto.db'):
            print(f"{Fore.RED}❌ No se encontró la base de datos 'rutas_moto.db'")
            print(f"{Fore.YELLOW}💡 Asegúrate de ejecutar este script desde el directorio del bot.")
            sys.exit(1)
        
        # Crear instancia de la base de datos
        db = Database()
        
        print(f"{Fore.GREEN}✅ Conectado a la base de datos correctamente")
        print(f"{Fore.WHITE}📝 Por favor, completa la información de la nueva ruta:\n")
        
        # Recopilar datos
        datos = {}
        
        # Campos obligatorios
        datos['nombre'] = get_input("🏍️  Nombre de la ruta", required=True)
        datos['link_ruta'] = get_input("🗺️  Enlace de Google Maps de la ruta", required=True, validate_url=True)
        datos['link_encuentro'] = get_input("📍 Punto de encuentro (Google Maps)", required=True, validate_url=True)
        
        # Campos opcionales
        print(f"\n{Fore.GREEN}🟢 Campos opcionales (puedes dejarlos vacíos):")
        datos['link_restaurante'] = get_input("🍽️  Restaurante (Google Maps)", validate_url=True)
        datos['fecha'] = get_input("📅 Fecha")
        datos['hora'] = get_input("⏰ Hora")
        
        # Usar valores por defecto si están vacíos
        if not datos['fecha']:
            datos['fecha'] = "Por definir"
        if not datos['hora']:
            datos['hora'] = "Por confirmar"
        
        # Mostrar resumen
        mostrar_resumen(datos)
        
        # Confirmar guardado
        if confirmar_guardado():
            # Guardar en base de datos
            ruta_id = db.agregar_ruta(
                nombre=datos['nombre'],
                link_ruta=datos['link_ruta'],
                link_encuentro=datos['link_encuentro'],
                link_restaurante=datos['link_restaurante'] or None,
                fecha=datos['fecha'],
                hora=datos['hora']
            )
            
            if ruta_id:
                print(f"\n{Fore.GREEN}✅ ¡Ruta agregada correctamente!")
                print(f"{Fore.CYAN}🆔 ID de la ruta: {ruta_id}")
                print(f"{Fore.YELLOW}💡 Ya puedes usar esta ruta en el bot de Telegram.")
            else:
                print(f"\n{Fore.RED}❌ Error al guardar la ruta en la base de datos.")
                sys.exit(1)
        else:
            print(f"\n{Fore.YELLOW}❌ Operación cancelada. No se guardó la ruta.")
    
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}❌ Operación cancelada por el usuario.")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Fore.RED}❌ Error inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
